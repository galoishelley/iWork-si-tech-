cp phone_head.ini      /is1/uisp/knownitf/cfg/gujl/phone_head.ini20091119   
cp work_addr.ini       /is1/uisp/knownitf/cfg/gujl/work_addr.ini20091119    
cp phone_head.ininew   /is1/uisp/knownitf/cfg/gujl/phone_head.ininew20091119
cp work_addr.ininew    /is1/uisp/knownitf/cfg/gujl/work_addr.ininew20091119 
cp bossinter.cfg       /is1/uisp/knownitf/cfg/gujl/bossinter.cfg20091119    
cp errorcode.cfgnew    /is1/uisp/knownitf/cfg/gujl/errorcode.cfgnew20091119 
cp worktocase.cfgnew   /is1/uisp/knownitf/cfg/gujl/worktocase.cfgnew20091119
cp TcpServer.cfg       /is1/uisp/knownitf/cfg/gujl/TcpServer.cfg20091119    
