int unencrypt(char * vPassWd,char * vEnPassWd, char * key, char *flag )
{
        char vKey[93+1];
        char vFlag[1+1];
        char vPassWord[8+1];
        char vEnPassWord[8+1];
        char *p=NULL;
        char *q=NULL;
        char i=0,j=0,k=0,len=0,size=0;

        init(vKey);
        init(vFlag);
        init(vPassWord);
        init(vEnPassWord);
        strcpy(vKey,key);
        strcpy(vPassWord,vPassWd);
        strcpy(vFlag,flag);
        Trim(vFlag);
        Trim(vPassWord);
        Trim(vKey);

        p=vKey;
        len = strlen(vPassWord);
        s_debug("-------------p[%s]\n",p);
        s_debug("-------------vKey[%s]\n",vKey);
        s_debug("-------------vFlag[%s]\n",vFlag);
        printf("p=[%s]\nvKey=[%s]\nflag=[%s]\nlen=[%d]\n",p,vKey,vFlag,len);
        printf("vPassWord=[%s]\n",vPassWord);
        s_debug("------------vPassWord=[%s]\n",vPassWord);
        if(len <= 0)
        {
                return -2;
        }

        if(strcmp(vFlag,"0")==0)
        {
                for(i=0;i<len;i++)
                {
                        size =((int)vPassWord[i]-48+i+1)*(len/2+1);
                        vEnPassWord[i] = vKey[size];
                        printf("vEnPassWord[%d]=[%c]\n",i,vEnPassWord[i]);
                }
                vEnPassWord[len]='\0';
                strcpy(vEnPassWd,vEnPassWord);
                Trim(vEnPassWd);
                printf("vEnPassWord=[%s]\n",vEnPassWord);
        }
        else if(strcmp(vFlag,"1")==0)
        {
                s_debug("-------------------------111----\n");
                s_debug("-------------len[%d]\n",len);

                for(i=0;i<len;i++)
                {
                        q=strchr(p,vPassWord[i]);
                        s_debug("-----------q[%s]\n",q);
                        if(q)
                        {
                                k=q-p;
                        }
                        else if(!q)
                        {
                                s_debug("-------------------------222----\n");
                                return -3;
                        }
                        vEnPassWord[i]=k/(len/2+1)-i-1+48;
                        printf("vEnPassWord[%d]=[%c]\n",i,vEnPassWord[i]);
                        s_debug("vEnPassWord[%d]=[%c]\n",i,vEnPassWord[i]);
                }
                vEnPassWord[len]='\0';
                strcpy(vEnPassWd,vEnPassWord);
                Trim(vEnPassWd);
                printf("vEnPassWord=[%s]\n",vEnPassWord);
                s_debug("vEnPassWord[%s]\n",vEnPassWord);
        }
        else
        {
                return -4;
        }

        return 0;
}
