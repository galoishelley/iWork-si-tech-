#include "onoff.h"

int
readnet( int sockid,register char *ptr, short nbytes) 
{
	int nleft,nread;

	nleft=nbytes;
	while(nleft > 0) {
		nread = read(sockid,ptr,nleft);
printf("read(%d,%x,%d)==%d,[errno=%d]\n",sockid,ptr,nleft,nread,errno);
		if (nread <= 0 ) 
		{
			printf("read(%d,%x,%d)==%d,[errno=%d]\n",\
				sockid,ptr,nleft,nread,errno);
			close(sockid);
			return (nread);
		}

		nleft -=nread;
		ptr +=nread;
	}

	return nbytes-nleft;
}

int
writenet( int sockid,register char *ptr, short nbytes) 
{
	int nleft,nwrite;

	nleft=nbytes;
	printf("��������[%s]\n",ptr);
	while(nleft > 0) {
		nwrite = write(sockid,ptr,nleft);
		printf("nwrite=[%d]\n",nwrite);
		if (nwrite < 0 ) 
		{
			printf("write(%d,%x,%d)==%d,[errno=%d]\n",\
				sockid,ptr,nleft,nwrite,errno);
			close(sockid);
			return (nwrite);
		}
		printf("nleft1=[%d]\n",nleft);
		nleft -=nwrite;
	   printf("nleft=[%d]\n",nleft);
		ptr +=nwrite;
	}

	return nbytes-nleft;
}
