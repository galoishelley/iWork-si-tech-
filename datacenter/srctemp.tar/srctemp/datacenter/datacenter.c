
/* Result Sets Interface */
#ifndef SQL_CRSR
#  define SQL_CRSR
  struct sql_cursor
  {
    unsigned int curocn;
    void *ptr1;
    void *ptr2;
    unsigned int magic;
  };
  typedef struct sql_cursor sql_cursor;
  typedef struct sql_cursor SQL_CURSOR;
#endif /* SQL_CRSR */

/* Thread Safety */
typedef void * sql_context;
typedef void * SQL_CONTEXT;

/* Object support */
struct sqltvn
{
  unsigned char *tvnvsn; 
  unsigned short tvnvsnl; 
  unsigned char *tvnnm;
  unsigned short tvnnml; 
  unsigned char *tvnsnm;
  unsigned short tvnsnml;
};
typedef struct sqltvn sqltvn;

struct sqladts
{
  unsigned int adtvsn; 
  unsigned short adtmode; 
  unsigned short adtnum;  
  sqltvn adttvn[1];       
};
typedef struct sqladts sqladts;

static struct sqladts sqladt = {
  1,1,0,
};

/* Binding to PL/SQL Records */
struct sqltdss
{
  unsigned int tdsvsn; 
  unsigned short tdsnum; 
  unsigned char *tdsval[1]; 
};
typedef struct sqltdss sqltdss;
static struct sqltdss sqltds =
{
  1,
  0,
};

/* File name & Package Name */
struct sqlcxp
{
  unsigned short fillen;
           char  filnam[14];
};
static struct sqlcxp sqlfpn =
{
    13,
    "datacenter.pc"
};


static unsigned int sqlctx = 566779;


static struct sqlexd {
   unsigned long  sqlvsn;
   unsigned int   arrsiz;
   unsigned int   iters;
   unsigned int   offset;
   unsigned short selerr;
   unsigned short sqlety;
   unsigned int   occurs;
            short *cud;
   unsigned char  *sqlest;
            char  *stmt;
   sqladts *sqladtp;
   sqltdss *sqltdsp;
   unsigned char  **sqphsv;
   unsigned long  *sqphsl;
            int   *sqphss;
            short **sqpind;
            int   *sqpins;
   unsigned long  *sqparm;
   unsigned long  **sqparc;
   unsigned short  *sqpadto;
   unsigned short  *sqptdso;
   unsigned int   sqlcmax;
   unsigned int   sqlcmin;
   unsigned int   sqlcincr;
   unsigned int   sqlctimeout;
   unsigned int   sqlcnowait;
            int   sqfoff;
   unsigned int   sqcmod;
   unsigned int   sqfmod;
   unsigned char  *sqhstv[10];
   unsigned long  sqhstl[10];
            int   sqhsts[10];
            short *sqindv[10];
            int   sqinds[10];
   unsigned long  sqharm[10];
   unsigned long  *sqharc[10];
   unsigned short  sqadto[10];
   unsigned short  sqtdso[10];
} sqlstm = {12,10};

/* SQLLIB Prototypes */
extern sqlcxt (/*_ void **, unsigned int *,
                   struct sqlexd *, struct sqlcxp * _*/);
extern sqlcx2t(/*_ void **, unsigned int *,
                   struct sqlexd *, struct sqlcxp * _*/);
extern sqlbuft(/*_ void **, char * _*/);
extern sqlgs2t(/*_ void **, char * _*/);
extern sqlorat(/*_ void **, unsigned int *, void * _*/);

/* Forms Interface */
static int IAPSUCC = 0;
static int IAPFAIL = 1403;
static int IAPFTL  = 535;
extern void sqliem(/*_ char *, int * _*/);

typedef struct { unsigned short len; unsigned char arr[1]; } VARCHAR;
typedef struct { unsigned short len; unsigned char arr[1]; } varchar;

/* CUD (Compilation Unit Data) Array */
static short sqlcud0[] =
{12,4130,852,0,0,
5,0,0,1,0,0,27,467,0,0,4,4,0,1,0,1,97,0,0,1,97,0,0,1,97,0,0,1,10,0,0,
36,0,0,2,86,0,4,579,0,0,4,1,0,1,0,2,97,0,0,2,97,0,0,2,97,0,0,1,97,0,0,
67,0,0,3,86,0,4,589,0,0,7,6,0,1,0,1,97,0,0,1,97,0,0,1,97,0,0,1,97,0,0,1,97,0,0,
1,97,0,0,2,97,0,0,
110,0,0,4,86,0,4,594,0,0,7,6,0,1,0,1,97,0,0,1,97,0,0,1,97,0,0,1,97,0,0,1,97,0,
0,1,97,0,0,2,97,0,0,
153,0,0,5,0,0,17,638,0,0,1,1,0,1,0,1,97,0,0,
172,0,0,5,0,0,21,639,0,0,1,1,0,1,0,1,97,0,0,
191,0,0,6,0,0,29,640,0,0,0,0,0,1,0,
206,0,0,5,0,0,17,646,0,0,1,1,0,1,0,1,97,0,0,
225,0,0,5,0,0,21,647,0,0,5,5,0,1,0,1,97,0,0,1,97,0,0,1,97,0,0,1,97,0,0,1,3,0,0,
260,0,0,7,0,0,29,655,0,0,0,0,0,1,0,
275,0,0,5,0,0,21,658,0,0,5,5,0,1,0,1,97,0,0,1,97,0,0,1,97,0,0,1,97,0,0,1,3,0,0,
310,0,0,8,0,0,29,663,0,0,0,0,0,1,0,
325,0,0,9,0,0,29,671,0,0,0,0,0,1,0,
340,0,0,10,0,0,29,677,0,0,0,0,0,1,0,
355,0,0,11,0,0,17,749,0,0,1,1,0,1,0,1,97,0,0,
374,0,0,11,0,0,45,752,0,0,0,0,0,1,0,
389,0,0,11,0,0,13,753,0,0,10,0,0,1,0,2,97,0,0,2,97,0,0,2,97,0,0,2,97,0,0,2,97,
0,0,2,97,0,0,2,97,0,0,2,97,0,0,2,97,0,0,2,97,0,0,
444,0,0,11,0,0,15,758,0,0,0,0,0,1,0,
459,0,0,12,0,0,29,759,0,0,0,0,0,1,0,
474,0,0,11,0,0,15,766,0,0,0,0,0,1,0,
489,0,0,13,0,0,29,767,0,0,0,0,0,1,0,
504,0,0,11,0,0,15,772,0,0,0,0,0,1,0,
519,0,0,14,0,0,29,773,0,0,0,0,0,1,0,
534,0,0,11,0,0,17,810,0,0,1,1,0,1,0,1,97,0,0,
553,0,0,11,0,0,45,813,0,0,1,1,0,1,0,1,97,0,0,
572,0,0,11,0,0,13,814,0,0,3,0,0,1,0,2,97,0,0,2,97,0,0,2,97,0,0,
599,0,0,11,0,0,15,817,0,0,0,0,0,1,0,
614,0,0,15,0,0,29,818,0,0,0,0,0,1,0,
629,0,0,11,0,0,15,825,0,0,0,0,0,1,0,
644,0,0,16,0,0,29,826,0,0,0,0,0,1,0,
659,0,0,11,0,0,15,830,0,0,0,0,0,1,0,
674,0,0,17,0,0,29,831,0,0,0,0,0,1,0,
689,0,0,11,0,0,17,857,0,0,1,1,0,1,0,1,97,0,0,
708,0,0,11,0,0,45,860,0,0,1,1,0,1,0,1,97,0,0,
727,0,0,11,0,0,13,861,0,0,1,0,0,1,0,2,97,0,0,
746,0,0,11,0,0,15,864,0,0,0,0,0,1,0,
761,0,0,18,0,0,29,865,0,0,0,0,0,1,0,
776,0,0,11,0,0,15,872,0,0,0,0,0,1,0,
791,0,0,19,0,0,29,873,0,0,0,0,0,1,0,
806,0,0,11,0,0,15,877,0,0,0,0,0,1,0,
821,0,0,20,0,0,29,878,0,0,0,0,0,1,0,
836,0,0,11,0,0,17,900,0,0,1,1,0,1,0,1,97,0,0,
855,0,0,11,0,0,45,903,0,0,1,1,0,1,0,1,97,0,0,
874,0,0,11,0,0,13,904,0,0,1,0,0,1,0,2,97,0,0,
893,0,0,11,0,0,15,907,0,0,0,0,0,1,0,
908,0,0,21,0,0,29,908,0,0,0,0,0,1,0,
923,0,0,11,0,0,15,916,0,0,0,0,0,1,0,
938,0,0,22,0,0,29,917,0,0,0,0,0,1,0,
953,0,0,11,0,0,15,922,0,0,0,0,0,1,0,
968,0,0,23,0,0,29,923,0,0,0,0,0,1,0,
};


#include "onoff.h"
#include "datacenter.h"
#include <sqlca.h>
#include <onoff.h>
#include <db_func.h>

#define	DBLOGIN		"/mdblogin.cfg"
#define	init(a)	memset(a,	0, sizeof(a))
#define	ENCRYPTKEY "PLMOKNIJBUHYGVTFCRDXESZAQWqazwsxedcrfvtgbyhnujmikolp1234567890~`!@#$%^&*()-_+=|\[]{}.,><?/;:"


void LogOut();
int GenDaemon();
int retbackcmd();

int runflag;
char user_name[32],user_pswd[32];
char srv_addr[32],srv_port[32];
char time_out[32];
char sendname[64],backname[64];

/* EXEC SQL INCLUDE SQLCA;
 */ 
/*
 * $Header: sqlca.h 24-apr-2003.12:50:58 mkandarp Exp $ sqlca.h 
 */

/* Copyright (c) 1985, 2003, Oracle Corporation.  All rights reserved.  */
 
/*
NAME
  SQLCA : SQL Communications Area.
FUNCTION
  Contains no code. Oracle fills in the SQLCA with status info
  during the execution of a SQL stmt.
NOTES
  **************************************************************
  ***                                                        ***
  *** This file is SOSD.  Porters must change the data types ***
  *** appropriately on their platform.  See notes/pcport.doc ***
  *** for more information.                                  ***
  ***                                                        ***
  **************************************************************

  If the symbol SQLCA_STORAGE_CLASS is defined, then the SQLCA
  will be defined to have this storage class. For example:
 
    #define SQLCA_STORAGE_CLASS extern
 
  will define the SQLCA as an extern.
 
  If the symbol SQLCA_INIT is defined, then the SQLCA will be
  statically initialized. Although this is not necessary in order
  to use the SQLCA, it is a good pgming practice not to have
  unitialized variables. However, some C compilers/OS's don't
  allow automatic variables to be init'd in this manner. Therefore,
  if you are INCLUDE'ing the SQLCA in a place where it would be
  an automatic AND your C compiler/OS doesn't allow this style
  of initialization, then SQLCA_INIT should be left undefined --
  all others can define SQLCA_INIT if they wish.

  If the symbol SQLCA_NONE is defined, then the SQLCA variable will
  not be defined at all.  The symbol SQLCA_NONE should not be defined
  in source modules that have embedded SQL.  However, source modules
  that have no embedded SQL, but need to manipulate a sqlca struct
  passed in as a parameter, can set the SQLCA_NONE symbol to avoid
  creation of an extraneous sqlca variable.
 
MODIFIED
    lvbcheng   07/31/98 -  long to int
    jbasu      12/12/94 -  Bug 217878: note this is an SOSD file
    losborne   08/11/92 -  No sqlca var if SQLCA_NONE macro set 
  Clare      12/06/84 - Ch SQLCA to not be an extern.
  Clare      10/21/85 - Add initialization.
  Bradbury   01/05/86 - Only initialize when SQLCA_INIT set
  Clare      06/12/86 - Add SQLCA_STORAGE_CLASS option.
*/
 
#ifndef SQLCA
#define SQLCA 1
 
struct   sqlca
         {
         /* ub1 */ char    sqlcaid[8];
         /* b4  */ int     sqlabc;
         /* b4  */ int     sqlcode;
         struct
           {
           /* ub2 */ unsigned short sqlerrml;
           /* ub1 */ char           sqlerrmc[70];
           } sqlerrm;
         /* ub1 */ char    sqlerrp[8];
         /* b4  */ int     sqlerrd[6];
         /* ub1 */ char    sqlwarn[8];
         /* ub1 */ char    sqlext[8];
         };

#ifndef SQLCA_NONE 
#ifdef   SQLCA_STORAGE_CLASS
SQLCA_STORAGE_CLASS struct sqlca sqlca
#else
         struct sqlca sqlca
#endif
 
#ifdef  SQLCA_INIT
         = {
         {'S', 'Q', 'L', 'C', 'A', ' ', ' ', ' '},
         sizeof(struct sqlca),
         0,
         { 0, {0}},
         {'N', 'O', 'T', ' ', 'S', 'E', 'T', ' '},
         {0, 0, 0, 0, 0, 0},
         {0, 0, 0, 0, 0, 0, 0, 0},
         {0, 0, 0, 0, 0, 0, 0, 0}
         }
#endif
         ;
#endif
 
#endif
 
/* end SQLCA */


/* EXEC SQL BEGIN DECLARE SECTION; */ 

    char sqlstmt[512+1];
    char tmpsql[1024+1];
    char command_id[20+1];
	char id_no[32];
	char hlr_code[4];
	char phone_no[20+1];
	char new_phone[15+1];
	char imsi_no[20+1];
	char new_imsi[20+1];
	char other_char[60+1];
	char cmd_type[20];
	char business_status[8];
	char command_code[8];
	char srv_type[32];
	char cmd_info[200];
	char offon_server[32];
	char offon_user[64];
	char offon_pswd[32];
	char cust_pswd[32];
	char dest_pswd[32];
	char cust_id[32];
	char add_no[32];
	char cust_name[60+1];
	char autolenflag[1+1];
	int  ret=0;
/* EXEC SQL END DECLARE SECTION; */ 


int retcode;
int TimeOut;

int isphone(phoneno)
char *phoneno;
{
  int val;

  if(strlen(phoneno)!=11)
    return -1;

  if(phoneno[0]!='1' || phoneno[1]!='3')
    return -1;

  val=atoi(phoneno+2);
  if(val<500000000 || val>999999999)
    return -1;

  return 0;
}

char *delspace(char *s)
{
  int i;

  for(i=strlen(s)-1;i>=0;i--)
    if(s[i]==' ' || s[i]=='\t')
      s[i]=0x0;
    else
      break;

  return s;
}

void catchalm(sig)
int sig;
{
  signal(sig,SIG_IGN);
  TimeOut=1;

  return;
}

char*	Trim(char	*S)
{
	int	I	=	0, i = 0,	L	=	0;

	if (!strstr(S, " ")) return	S;
	
	L	=	strlen(S)	-	1;
	
	I	=	0;
	
	while	(	(I <=	L) &&	(S[I]	<= ' ')	&& (S[I] > 0)	)
	{
		I	++;
	}
	if (I	>	L)
	{
		S[0] = '\0';
	}
	else
	{
		while	(	(S[L]	<= ' ')	 &&	(S[L]	>	0	)	)
		{
			L	--;
		}
		
		strncpy(S, S + I,	L	+	1);
		
		S[L	+	1	-	I] = '\0';
	}
	
	return S;
}

/************************************************************************
��������:	unencrypt()
����ʱ��:	2010/06/29
������Ա:	liuweib
��������:	�û����˻����ͻ�����ӽ���
�������:	
�������:	
�� ��	ֵ:	0	��������,	1	����
************************************************************************/
int	unencrypt(char * vPassWd,char	*	vEnPassWd, char	*	key, char	*flag	)
{
	char vKey[93+1];
	char vFlag[1+1];
	char vPassWord[8+1];
	char vEnPassWord[8+1];
	char *p=NULL;
	char *q=NULL;
	char i=0,j=0,k=0,len=0,size=0;
	
	init(vKey);
	init(vFlag);
	init(vPassWord);
	init(vEnPassWord);
	strcpy(vKey,key);
	strcpy(vPassWord,vPassWd);
	strcpy(vFlag,flag);
	Trim(vFlag);
	Trim(vPassWord);
	Trim(vKey);
	
	p=vKey;
	len	=	strlen(vPassWord);
	printf("p=[%s]\nvKey=[%s]\nflag=[%s]\nlen=[%d]\n",p,vKey,vFlag,len);
	printf("vPassWord=[%s]\n",vPassWord);
	if(len <=	0)
	{
		return -2;
	}
	
	if(strcmp(vFlag,"0")==0)
	{
		for(i=0;i<len;i++)
		{	
			size =((int)vPassWord[i]-48+i+1)*(len/2+1);
			vEnPassWord[i] = vKey[size];
			printf("vEnPassWord[%d]=[%c]\n",i,vEnPassWord[i]);
		}
		vEnPassWord[len]='\0';
		strcpy(vEnPassWd,vEnPassWord);
		Trim(vEnPassWd);
		printf("vEnPassWord=[%s]\n",vEnPassWord);
	}
	else if(strcmp(vFlag,"1")==0)
	{
		for(i=0;i<len;i++)
		{	
			q=strchr(p,vPassWord[i]);
			if(q)
			{
				k=q-p;
			}
			else if(!q)
			{
				return -3;
			}
			vEnPassWord[i]=k/(len/2+1)-i-1+48;
			printf("vEnPassWord[%d]=[%c]\n",i,vEnPassWord[i]);
		}
		vEnPassWord[len]='\0';
		strcpy(vEnPassWd,vEnPassWord);
		Trim(vEnPassWd);
		printf("vEnPassWord=[%s]\n",vEnPassWord);
	}
	else
	{
		return -4;
	}
	
	return 0;
}

int cmd_deal(servtype,username,userpswd,data,ip,port,timeout)
char *servtype;
char *username;
char *userpswd;
char *data;
char *ip;
int port;
int timeout;
{
  struct sockaddr_in srv_addr;
  int sockid;
  char buf[DATALEN+1];
  int ret_no;
  struct ServMsg *info;

  memset(&srv_addr,0x0,sizeof(srv_addr));
  srv_addr.sin_family=AF_INET;
  srv_addr.sin_addr.s_addr=inet_addr(ip);
  srv_addr.sin_port=htons(port);

  sockid=socket(AF_INET,SOCK_STREAM,0);
  if(sockid<0)
    return -1;

  TimeOut=0;
  signal(SIGALRM,catchalm);
  alarm(timeout);

  if(connect(sockid,(struct sockaddr *)&srv_addr,sizeof(srv_addr))<0)
  {
    if(TimeOut)
      return -100;
    else
      return -2;
  }
  
printf("connect OK!\n");

  memset(buf,0x0,sizeof(buf));
  info=(struct ServMsg *)buf;

  memcpy(info->msgflag,MSGFLAG,4);
  info->msgtype[0]=REQ_MSG;
  sprintf(info->servtype,"%- 15s",servtype);
  sprintf(info->username,"%- 10s",username);
  sprintf(info->userpswd,"%- 10s",userpswd);
  memcpy(info->msgno,"                ",16);
  memcpy(info->reserved,"                ",16);
  strcpy(info->msgbody,delspace(data));
  
/*
memset(info->msgbody,' ',200);
delspace(data);
memcpy(info->msgbody,data,strlen(data));
*/

  printf("SND:%s[%d:%d]\n",buf,DATALEN,strlen(buf));
  s_debug("SND:%s[%d:%d]\n",buf,DATALEN,strlen(buf));

  if(writenet(sockid,buf,DATALEN)<0)
  {
    close(sockid);

    if(TimeOut)
      return -100;
    else
      return -3;
  }

  memset(buf,0x0,sizeof(buf));
  if(readnet(sockid,buf,DATALEN)<=0)
  {
    close(sockid);

    if(TimeOut)
      return -100;
    else
      return -4;
  }
  printf("RCV:%s[%d]\n",buf,DATALEN);
  s_debug("RCV:%s[%d]\n",buf,DATALEN);

  signal(SIGALRM,SIG_IGN);
  close(sockid);

  if(strncmp(info->msgflag,MSGFLAG,4))
    return -11;

  if(strncmp(info->msgbody,"RETN=",5))
    return -12;

  return atoi(info->msgbody+5);
}

void mmadd(char *str,char *user,char *pswd,char *name)
{
	char dbuser[128],dbpswd[128],dbname[128];
	char tmp[8];
	int i,len;

	memset(dbuser,0x0,sizeof(dbuser));
	memset(dbpswd,0x0,sizeof(dbpswd));
	memset(dbname,0x0,sizeof(dbname));

	for(i=0,len=strlen(user);i<len;i++)
	{
		memset(tmp,0x0,sizeof(tmp));
		sprintf(tmp,"%02x",user[i]-0x10);
		strcat(dbuser,tmp);
	}

	for(i=0,len=strlen(pswd);i<len;i++)
	{
		memset(tmp,0x0,sizeof(tmp));
		sprintf(tmp,"%02x",pswd[i]-0x10);
		strcat(dbpswd,tmp);
	}

	for(i=0,len=strlen(name);i<len;i++)
	{
		memset(tmp,0x0,sizeof(tmp));
		sprintf(tmp,"%02x",name[i]-0x10);
		strcat(dbname,tmp);
	}

	sprintf(str,"mmtext%s10%s10%s\0",dbuser,dbpswd,dbname);

	return;
}

void mmdel(char *str,char *user,char *pswd,char *name)
{
	char tmp[256],dbstr[256];
	int i,len;

	memset(dbstr,0x0,sizeof(dbstr));
	memset(tmp,0x0,sizeof(tmp));
	strcpy(tmp,str+6);

	for(i=0,len=strlen(tmp);i<len;i+=2)
	{
		if(tmp[i+1]>='a')
			dbstr[i/2]=((tmp[i]-'0')*16+(tmp[i+1]-'a'+10))+0x10;
		else
			dbstr[i/2]=((tmp[i]-'0')*16+(tmp[i+1]-'0'))+0x10;
	}

	sscanf(dbstr,"%s%s%s",user,pswd,name);

	return;
}

int main(int argc,char **argv)
{
	int i,ret,num_count;
	char retcodestr[4],flag[2],cmdstr[128],cmdpara[8],tmpstr[128];
	time_t start,finish;
	double elapsed_time;
	FILE *fp;
	int filemode;
	char dclogin[256];

	if(argc!=2)
	{
		printf("Usage:%s cfg_file\n\nVERSION:v1.1\n\n",argv[0]);
		exit(1);
	}

	memset(dclogin,0x0,sizeof(dclogin));
	strcpy(dclogin,argv[1]);

	runflag=0;

	/*---------------- Created stand daemon process-------------------- */
    if (GenDaemon()<0) {
        s_debug("Run gsmmaster fail![%s] [%d]\n",__FILE__,__LINE__);
        printf("\nRun gsmmaster failed !!\n");
        exit(1);
    }

	signal(SIGTERM,LogOut);
	signal(SIGPIPE,SIG_IGN);
	signal(SIGCLD,SIG_IGN);

	memset(user_name,0x0,sizeof(user_name));
	memset(user_pswd,0x0,sizeof(user_pswd));
	memset(srv_addr,0x0,sizeof(srv_addr));
	memset(srv_port,0x0,sizeof(srv_port));
	memset(time_out,0x0,sizeof(time_out));
	memset(offon_server,0x0,sizeof(offon_server));
	memset(offon_user,0x0,sizeof(offon_user));
	memset(offon_pswd,0x0,sizeof(offon_pswd));
	
	printf("will get ETCDIR!\n");
	printf("dclogin[0][%c]\n",dclogin[0]);
	memset(cmdstr,0x0,sizeof(cmdstr));
	if(dclogin[0]=='/')
		strcpy(cmdstr,dclogin);
	else
		sprintf(cmdstr,"%s/%s",getenv("ETCDIR"),dclogin);
		
	printf("dclogin cmdstr=[%s]\n",cmdstr);

	fp=fopen(cmdstr,"r");
	if(fp==NULL)
	{
		s_debug("fopen(%s,r) failed\n",cmdstr);
		exit(1);
	}

	/*
	memset(tmpstr,0x0,sizeof(tmpstr));
	fscanf(fp,"%s%s%s%s",tmpstr,offon_user,offon_pswd,offon_server);
	if(strcmp(tmpstr,"OFFON"))
	{
		printf("configure file error\n");
		fclose(fp);
		exit(1);
	}
	*/

	memset(sendname,0x0,sizeof(sendname));
	memset(backname,0x0,sizeof(backname));
	
	
	fscanf(fp,"%s%s%s%s%s%s%s",sendname,backname,user_name,user_pswd,srv_addr,srv_port,time_out);
	fclose(fp);

	memset(cmdstr,0x0,sizeof(cmdstr));
	strcpy(cmdstr,getenv("ETCDIR"));
	strcat(cmdstr,DBLOGIN);
printf("DBLOGIN cmdstr=[%s]\n",cmdstr);
	fp=fopen(cmdstr,"r");
	if(fp==NULL)
	{
		s_debug("can't open %s for read[%d]\n",cmdstr,errno);		
		exit(1);
	}

	memset(tmpstr,0x0,sizeof(tmpstr));
	fgets(tmpstr,sizeof(tmpstr),fp);

	if(strncmp(tmpstr,"mmtext",6)==0)
	{
		mmdel(tmpstr,offon_user,offon_pswd,offon_server);
	}
	else
	{
		sscanf(tmpstr,"%s%s%s",offon_user,offon_pswd,offon_server);
	}
	fclose(fp);
	
	
	/* EXEC SQL WHENEVER SQLERROR DO error_handler(); */ 

	/* EXEC SQL WHENEVER SQLWARNING DO warning_handler(); */ 

	/* EXEC SQL WHENEVER NOT FOUND CONTINUE; */ 



	/* EXEC SQL CONNECT :offon_user IDENTIFIED by :offon_pswd
		using :offon_server; */ 

{
 struct sqlexd sqlstm;
 sqlstm.sqlvsn = 12;
 sqlstm.arrsiz = 4;
 sqlstm.sqladtp = &sqladt;
 sqlstm.sqltdsp = &sqltds;
 sqlstm.iters = (unsigned int  )10;
 sqlstm.offset = (unsigned int  )5;
 sqlstm.cud = sqlcud0;
 sqlstm.sqlest = (unsigned char  *)&sqlca;
 sqlstm.sqlety = (unsigned short)256;
 sqlstm.occurs = (unsigned int  )0;
 sqlstm.sqhstv[0] = (unsigned char  *)offon_user;
 sqlstm.sqhstl[0] = (unsigned long )64;
 sqlstm.sqhsts[0] = (         int  )64;
 sqlstm.sqindv[0] = (         short *)0;
 sqlstm.sqinds[0] = (         int  )0;
 sqlstm.sqharm[0] = (unsigned long )0;
 sqlstm.sqadto[0] = (unsigned short )0;
 sqlstm.sqtdso[0] = (unsigned short )0;
 sqlstm.sqhstv[1] = (unsigned char  *)offon_pswd;
 sqlstm.sqhstl[1] = (unsigned long )32;
 sqlstm.sqhsts[1] = (         int  )32;
 sqlstm.sqindv[1] = (         short *)0;
 sqlstm.sqinds[1] = (         int  )0;
 sqlstm.sqharm[1] = (unsigned long )0;
 sqlstm.sqadto[1] = (unsigned short )0;
 sqlstm.sqtdso[1] = (unsigned short )0;
 sqlstm.sqhstv[2] = (unsigned char  *)offon_server;
 sqlstm.sqhstl[2] = (unsigned long )32;
 sqlstm.sqhsts[2] = (         int  )32;
 sqlstm.sqindv[2] = (         short *)0;
 sqlstm.sqinds[2] = (         int  )0;
 sqlstm.sqharm[2] = (unsigned long )0;
 sqlstm.sqadto[2] = (unsigned short )0;
 sqlstm.sqtdso[2] = (unsigned short )0;
 sqlstm.sqphsv = sqlstm.sqhstv;
 sqlstm.sqphsl = sqlstm.sqhstl;
 sqlstm.sqphss = sqlstm.sqhsts;
 sqlstm.sqpind = sqlstm.sqindv;
 sqlstm.sqpins = sqlstm.sqinds;
 sqlstm.sqparm = sqlstm.sqharm;
 sqlstm.sqparc = sqlstm.sqharc;
 sqlstm.sqpadto = sqlstm.sqadto;
 sqlstm.sqptdso = sqlstm.sqtdso;
 sqlstm.sqlcmax = (unsigned int )100;
 sqlstm.sqlcmin = (unsigned int )2;
 sqlstm.sqlcincr = (unsigned int )1;
 sqlstm.sqlctimeout = (unsigned int )0;
 sqlstm.sqlcnowait = (unsigned int )0;
 sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
 if (sqlca.sqlcode < 0) error_handler();
 if (sqlca.sqlwarn[0] == 'W') warning_handler();
}



	if(SQLCODE)
	{
		s_debug("can't connect to OFFON \n");
		printf("offon_user=====%s~\n",offon_user);
		printf("offon_pswd=====%s~\n",offon_pswd);
		printf("offon_server===%s~\n",offon_server);
		exit(1);
	}
	else
		s_debug("connect to OFFON success\n");

	while(1)
	{
	    runflag=0;
		memset(add_no,0x0,sizeof(add_no));

	    	memset(cmd_info,0,sizeof(cmd_info));


        ret=getcommand(sendname);

printf("getcommand()===%d\n",ret);
	    if (ret<0)
	    {
			s_debug("Err:3840 return %d from database\n",ret);
			exit(1);
	    }
	    else if(ret==0)
	    {
			printf("Now no any datas in database!\n");
			sleep(8);
			continue;
	    }
		else if(ret>1)
		{
			ret=retbackcmd(sendname,backname);
			sleep(8);
			continue;
		}

		memset(cmd_type,0x0,sizeof(cmd_type));
		memset(cmd_info,0x0,sizeof(cmd_info));
		memset(autolenflag,0x0,sizeof(autolenflag));

		strcat(command_code,business_status);
printf("command_code==%s[%d]\n",command_code,atoi(command_code));

/*
		if(atoi(command_code)==280)
		{
			strcpy(cmd_type,"DEL:CJH");
			sprintf(cmd_info,"PHONENO=%s;",phone_no);
		}
		else if(atoi(command_code)==281)
		{
			strcpy(cmd_type,"ADD:CJH");
			sprintf(cmd_info,"PHONENO=%s,SUPERNO=%s,PSWD=%s,NAME=%s;",phone_no,add_no,dest_pswd,cust_name);
		}
		else if(atoi(command_code)==270)
		{
			strcpy(cmd_type,"DEL:YYXX");
			sprintf(cmd_info,"PHONENO=%s;",phone_no);
		}
		else if(atoi(command_code)==271)
		{
			strcpy(cmd_type,"ADD:YYXX");
			sprintf(cmd_info,"PHONENO=%s,PSWD=%s,NAME=%s;",phone_no,dest_pswd,cust_name);
		}
		else if(atoi(command_code)==240)
		{
			strcpy(cmd_type,"DEL:YDMS");
			sprintf(cmd_info,"PHONENO=%s;",phone_no);
		}
		else if(atoi(command_code)==241)
		{
			strcpy(cmd_type,"ADD:YDMS");
			sprintf(cmd_info,"PHONENO=%s,PSWD=%s,NAME=%s;",phone_no,dest_pswd,cust_name);
		}
		else if(atoi(command_code)==291 || atoi(command_code)==290)
		{
			strcpy(cmd_type,"MOD:KHZL");
			sprintf(cmd_info,"PHONENO=%s,SUPERNO=%s,PSWD=%s,NAME=%s,SEX=;",phone_no,add_no,dest_pswd,cust_name);
		}
*/	

/*�����滻,������Ѿ���Ϊ�ӿڷ�ʽ��������,�˲��ֽ�ȡ��*/	
		if(atoi(command_code)==281)
		{	strcpy(new_phone,add_no);
			strcpy(imsi_no,dest_pswd);
			strcpy(other_char,cust_name);			
		}
		else if(atoi(command_code)==271)
		{
			strcpy(imsi_no,dest_pswd);
			strcpy(other_char,cust_name);	
		}
		else if(atoi(command_code)==241)
		{
			strcpy(imsi_no,dest_pswd);
			strcpy(other_char,cust_name);	
		}
		else if(atoi(command_code)==291 || atoi(command_code)==290)
		{
			strcpy(new_phone,add_no);
			strcpy(imsi_no,dest_pswd);
			strcpy(other_char,cust_name);	
		};
		
/*ȡ���������ƺ�������*/		
		/* EXEC SQL  select cmdname,cmdinfo,autolenflag into :cmd_type,:cmd_info,:autolenflag from ccmdinfo 
			  where cmdcode=:command_code; */ 

{
  struct sqlexd sqlstm;
  sqlstm.sqlvsn = 12;
  sqlstm.arrsiz = 4;
  sqlstm.sqladtp = &sqladt;
  sqlstm.sqltdsp = &sqltds;
  sqlstm.stmt = "select cmdname ,cmdinfo ,autolenflag into :b0,:b1,:b2  fro\
m ccmdinfo where cmdcode=:b3";
  sqlstm.iters = (unsigned int  )1;
  sqlstm.offset = (unsigned int  )36;
  sqlstm.selerr = (unsigned short)1;
  sqlstm.cud = sqlcud0;
  sqlstm.sqlest = (unsigned char  *)&sqlca;
  sqlstm.sqlety = (unsigned short)256;
  sqlstm.occurs = (unsigned int  )0;
  sqlstm.sqhstv[0] = (unsigned char  *)cmd_type;
  sqlstm.sqhstl[0] = (unsigned long )20;
  sqlstm.sqhsts[0] = (         int  )0;
  sqlstm.sqindv[0] = (         short *)0;
  sqlstm.sqinds[0] = (         int  )0;
  sqlstm.sqharm[0] = (unsigned long )0;
  sqlstm.sqadto[0] = (unsigned short )0;
  sqlstm.sqtdso[0] = (unsigned short )0;
  sqlstm.sqhstv[1] = (unsigned char  *)cmd_info;
  sqlstm.sqhstl[1] = (unsigned long )200;
  sqlstm.sqhsts[1] = (         int  )0;
  sqlstm.sqindv[1] = (         short *)0;
  sqlstm.sqinds[1] = (         int  )0;
  sqlstm.sqharm[1] = (unsigned long )0;
  sqlstm.sqadto[1] = (unsigned short )0;
  sqlstm.sqtdso[1] = (unsigned short )0;
  sqlstm.sqhstv[2] = (unsigned char  *)autolenflag;
  sqlstm.sqhstl[2] = (unsigned long )2;
  sqlstm.sqhsts[2] = (         int  )0;
  sqlstm.sqindv[2] = (         short *)0;
  sqlstm.sqinds[2] = (         int  )0;
  sqlstm.sqharm[2] = (unsigned long )0;
  sqlstm.sqadto[2] = (unsigned short )0;
  sqlstm.sqtdso[2] = (unsigned short )0;
  sqlstm.sqhstv[3] = (unsigned char  *)command_code;
  sqlstm.sqhstl[3] = (unsigned long )8;
  sqlstm.sqhsts[3] = (         int  )0;
  sqlstm.sqindv[3] = (         short *)0;
  sqlstm.sqinds[3] = (         int  )0;
  sqlstm.sqharm[3] = (unsigned long )0;
  sqlstm.sqadto[3] = (unsigned short )0;
  sqlstm.sqtdso[3] = (unsigned short )0;
  sqlstm.sqphsv = sqlstm.sqhstv;
  sqlstm.sqphsl = sqlstm.sqhstl;
  sqlstm.sqphss = sqlstm.sqhsts;
  sqlstm.sqpind = sqlstm.sqindv;
  sqlstm.sqpins = sqlstm.sqinds;
  sqlstm.sqparm = sqlstm.sqharm;
  sqlstm.sqparc = sqlstm.sqharc;
  sqlstm.sqpadto = sqlstm.sqadto;
  sqlstm.sqptdso = sqlstm.sqtdso;
  sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
  if (sqlca.sqlcode < 0) error_handler();
  if (sqlca.sqlwarn[0] == 'W') warning_handler();
}


			  
/*�����ָ��������滻*/  
		if(SQLCODE==0)
		{
			
			printf("cmd_type=[%s][%s]\n",cmd_type,cmd_info);			
			if (atoi(autolenflag)==0)
			{					 	
			 	/* EXEC SQL select freplace(:cmd_info,'$1',:phone_no,'$2',:new_phone,'$3',:imsi_no,'$4',:new_imsi,'$5',:other_char) into :cmd_info from dual; */ 

{
     struct sqlexd sqlstm;
     sqlstm.sqlvsn = 12;
     sqlstm.arrsiz = 7;
     sqlstm.sqladtp = &sqladt;
     sqlstm.sqltdsp = &sqltds;
     sqlstm.stmt = "select freplace(:b0,'$1',:b1,'$2',:b2,'$3',:b3,'$4',:b4\
,'$5',:b5) into :b0  from dual ";
     sqlstm.iters = (unsigned int  )1;
     sqlstm.offset = (unsigned int  )67;
     sqlstm.selerr = (unsigned short)1;
     sqlstm.cud = sqlcud0;
     sqlstm.sqlest = (unsigned char  *)&sqlca;
     sqlstm.sqlety = (unsigned short)256;
     sqlstm.occurs = (unsigned int  )0;
     sqlstm.sqhstv[0] = (unsigned char  *)cmd_info;
     sqlstm.sqhstl[0] = (unsigned long )200;
     sqlstm.sqhsts[0] = (         int  )0;
     sqlstm.sqindv[0] = (         short *)0;
     sqlstm.sqinds[0] = (         int  )0;
     sqlstm.sqharm[0] = (unsigned long )0;
     sqlstm.sqadto[0] = (unsigned short )0;
     sqlstm.sqtdso[0] = (unsigned short )0;
     sqlstm.sqhstv[1] = (unsigned char  *)phone_no;
     sqlstm.sqhstl[1] = (unsigned long )21;
     sqlstm.sqhsts[1] = (         int  )0;
     sqlstm.sqindv[1] = (         short *)0;
     sqlstm.sqinds[1] = (         int  )0;
     sqlstm.sqharm[1] = (unsigned long )0;
     sqlstm.sqadto[1] = (unsigned short )0;
     sqlstm.sqtdso[1] = (unsigned short )0;
     sqlstm.sqhstv[2] = (unsigned char  *)new_phone;
     sqlstm.sqhstl[2] = (unsigned long )16;
     sqlstm.sqhsts[2] = (         int  )0;
     sqlstm.sqindv[2] = (         short *)0;
     sqlstm.sqinds[2] = (         int  )0;
     sqlstm.sqharm[2] = (unsigned long )0;
     sqlstm.sqadto[2] = (unsigned short )0;
     sqlstm.sqtdso[2] = (unsigned short )0;
     sqlstm.sqhstv[3] = (unsigned char  *)imsi_no;
     sqlstm.sqhstl[3] = (unsigned long )21;
     sqlstm.sqhsts[3] = (         int  )0;
     sqlstm.sqindv[3] = (         short *)0;
     sqlstm.sqinds[3] = (         int  )0;
     sqlstm.sqharm[3] = (unsigned long )0;
     sqlstm.sqadto[3] = (unsigned short )0;
     sqlstm.sqtdso[3] = (unsigned short )0;
     sqlstm.sqhstv[4] = (unsigned char  *)new_imsi;
     sqlstm.sqhstl[4] = (unsigned long )21;
     sqlstm.sqhsts[4] = (         int  )0;
     sqlstm.sqindv[4] = (         short *)0;
     sqlstm.sqinds[4] = (         int  )0;
     sqlstm.sqharm[4] = (unsigned long )0;
     sqlstm.sqadto[4] = (unsigned short )0;
     sqlstm.sqtdso[4] = (unsigned short )0;
     sqlstm.sqhstv[5] = (unsigned char  *)other_char;
     sqlstm.sqhstl[5] = (unsigned long )61;
     sqlstm.sqhsts[5] = (         int  )0;
     sqlstm.sqindv[5] = (         short *)0;
     sqlstm.sqinds[5] = (         int  )0;
     sqlstm.sqharm[5] = (unsigned long )0;
     sqlstm.sqadto[5] = (unsigned short )0;
     sqlstm.sqtdso[5] = (unsigned short )0;
     sqlstm.sqhstv[6] = (unsigned char  *)cmd_info;
     sqlstm.sqhstl[6] = (unsigned long )200;
     sqlstm.sqhsts[6] = (         int  )0;
     sqlstm.sqindv[6] = (         short *)0;
     sqlstm.sqinds[6] = (         int  )0;
     sqlstm.sqharm[6] = (unsigned long )0;
     sqlstm.sqadto[6] = (unsigned short )0;
     sqlstm.sqtdso[6] = (unsigned short )0;
     sqlstm.sqphsv = sqlstm.sqhstv;
     sqlstm.sqphsl = sqlstm.sqhstl;
     sqlstm.sqphss = sqlstm.sqhsts;
     sqlstm.sqpind = sqlstm.sqindv;
     sqlstm.sqpins = sqlstm.sqinds;
     sqlstm.sqparm = sqlstm.sqharm;
     sqlstm.sqparc = sqlstm.sqharc;
     sqlstm.sqpadto = sqlstm.sqadto;
     sqlstm.sqptdso = sqlstm.sqtdso;
     sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
     if (sqlca.sqlcode < 0) error_handler();
     if (sqlca.sqlwarn[0] == 'W') warning_handler();
}

		 	
			 	printf("cmdinfo1=[%s],sqlcode=[%d]\n",cmd_info,SQLCODE);
			}
		 	else
		 	{
		 		/* EXEC SQL select freplace(:cmd_info,'#1',:phone_no,'#2',:new_phone,'#3',:imsi_no,'#4',:new_imsi,'#5',:other_char) into :cmd_info from dual; */ 

{
     struct sqlexd sqlstm;
     sqlstm.sqlvsn = 12;
     sqlstm.arrsiz = 7;
     sqlstm.sqladtp = &sqladt;
     sqlstm.sqltdsp = &sqltds;
     sqlstm.stmt = "select freplace(:b0,'#1',:b1,'#2',:b2,'#3',:b3,'#4',:b4\
,'#5',:b5) into :b0  from dual ";
     sqlstm.iters = (unsigned int  )1;
     sqlstm.offset = (unsigned int  )110;
     sqlstm.selerr = (unsigned short)1;
     sqlstm.cud = sqlcud0;
     sqlstm.sqlest = (unsigned char  *)&sqlca;
     sqlstm.sqlety = (unsigned short)256;
     sqlstm.occurs = (unsigned int  )0;
     sqlstm.sqhstv[0] = (unsigned char  *)cmd_info;
     sqlstm.sqhstl[0] = (unsigned long )200;
     sqlstm.sqhsts[0] = (         int  )0;
     sqlstm.sqindv[0] = (         short *)0;
     sqlstm.sqinds[0] = (         int  )0;
     sqlstm.sqharm[0] = (unsigned long )0;
     sqlstm.sqadto[0] = (unsigned short )0;
     sqlstm.sqtdso[0] = (unsigned short )0;
     sqlstm.sqhstv[1] = (unsigned char  *)phone_no;
     sqlstm.sqhstl[1] = (unsigned long )21;
     sqlstm.sqhsts[1] = (         int  )0;
     sqlstm.sqindv[1] = (         short *)0;
     sqlstm.sqinds[1] = (         int  )0;
     sqlstm.sqharm[1] = (unsigned long )0;
     sqlstm.sqadto[1] = (unsigned short )0;
     sqlstm.sqtdso[1] = (unsigned short )0;
     sqlstm.sqhstv[2] = (unsigned char  *)new_phone;
     sqlstm.sqhstl[2] = (unsigned long )16;
     sqlstm.sqhsts[2] = (         int  )0;
     sqlstm.sqindv[2] = (         short *)0;
     sqlstm.sqinds[2] = (         int  )0;
     sqlstm.sqharm[2] = (unsigned long )0;
     sqlstm.sqadto[2] = (unsigned short )0;
     sqlstm.sqtdso[2] = (unsigned short )0;
     sqlstm.sqhstv[3] = (unsigned char  *)imsi_no;
     sqlstm.sqhstl[3] = (unsigned long )21;
     sqlstm.sqhsts[3] = (         int  )0;
     sqlstm.sqindv[3] = (         short *)0;
     sqlstm.sqinds[3] = (         int  )0;
     sqlstm.sqharm[3] = (unsigned long )0;
     sqlstm.sqadto[3] = (unsigned short )0;
     sqlstm.sqtdso[3] = (unsigned short )0;
     sqlstm.sqhstv[4] = (unsigned char  *)new_imsi;
     sqlstm.sqhstl[4] = (unsigned long )21;
     sqlstm.sqhsts[4] = (         int  )0;
     sqlstm.sqindv[4] = (         short *)0;
     sqlstm.sqinds[4] = (         int  )0;
     sqlstm.sqharm[4] = (unsigned long )0;
     sqlstm.sqadto[4] = (unsigned short )0;
     sqlstm.sqtdso[4] = (unsigned short )0;
     sqlstm.sqhstv[5] = (unsigned char  *)other_char;
     sqlstm.sqhstl[5] = (unsigned long )61;
     sqlstm.sqhsts[5] = (         int  )0;
     sqlstm.sqindv[5] = (         short *)0;
     sqlstm.sqinds[5] = (         int  )0;
     sqlstm.sqharm[5] = (unsigned long )0;
     sqlstm.sqadto[5] = (unsigned short )0;
     sqlstm.sqtdso[5] = (unsigned short )0;
     sqlstm.sqhstv[6] = (unsigned char  *)cmd_info;
     sqlstm.sqhstl[6] = (unsigned long )200;
     sqlstm.sqhsts[6] = (         int  )0;
     sqlstm.sqindv[6] = (         short *)0;
     sqlstm.sqinds[6] = (         int  )0;
     sqlstm.sqharm[6] = (unsigned long )0;
     sqlstm.sqadto[6] = (unsigned short )0;
     sqlstm.sqtdso[6] = (unsigned short )0;
     sqlstm.sqphsv = sqlstm.sqhstv;
     sqlstm.sqphsl = sqlstm.sqhstl;
     sqlstm.sqphss = sqlstm.sqhsts;
     sqlstm.sqpind = sqlstm.sqindv;
     sqlstm.sqpins = sqlstm.sqinds;
     sqlstm.sqparm = sqlstm.sqharm;
     sqlstm.sqparc = sqlstm.sqharc;
     sqlstm.sqpadto = sqlstm.sqadto;
     sqlstm.sqptdso = sqlstm.sqtdso;
     sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
     if (sqlca.sqlcode < 0) error_handler();
     if (sqlca.sqlwarn[0] == 'W') warning_handler();
}

		 	
			 	printf("cmdinfo2=[%s],sqlcode=[%d]\n",cmd_info,SQLCODE);
		 	}				
		}
		else
		{
			ret=retbackcmd(sendname,backname);
			sleep(8);
			continue;
		};

	        runflag=1;

printf("cmd_info==%s~\n",cmd_info);
		retcode=cmd_deal(cmd_type,user_name,user_pswd,cmd_info,srv_addr,atoi(srv_port),atoi(time_out));
printf("cmd_deal()==%d\n",retcode);

		if(retcode==0)
			retcode=3999;
		else if(retcode<0)
			break;
		else
			retcode+=3700;


		ret=retbackcmd(sendname,backname);

	}
}

int retbackcmd(char *sendname,char *backname)
{
	
	delspace(phone_no);
	delspace(command_code);
	delspace(business_status);
	delspace(new_phone);
	delspace(imsi_no);
	delspace(new_imsi);
	delspace(other_char);
	command_code[2]=0;
	memset(tmpsql,0x0,sizeof(tmpsql));
    sprintf(tmpsql, "UPDATE %s SET send_status='1',send_time=sysdate WHERE command_id= to_number(:v1)",sendname);

    /* EXEC SQL PREPARE stmt FROM :tmpsql; */ 

{
    struct sqlexd sqlstm;
    sqlstm.sqlvsn = 12;
    sqlstm.arrsiz = 7;
    sqlstm.sqladtp = &sqladt;
    sqlstm.sqltdsp = &sqltds;
    sqlstm.stmt = "";
    sqlstm.iters = (unsigned int  )1;
    sqlstm.offset = (unsigned int  )153;
    sqlstm.cud = sqlcud0;
    sqlstm.sqlest = (unsigned char  *)&sqlca;
    sqlstm.sqlety = (unsigned short)256;
    sqlstm.occurs = (unsigned int  )0;
    sqlstm.sqhstv[0] = (unsigned char  *)tmpsql;
    sqlstm.sqhstl[0] = (unsigned long )1025;
    sqlstm.sqhsts[0] = (         int  )0;
    sqlstm.sqindv[0] = (         short *)0;
    sqlstm.sqinds[0] = (         int  )0;
    sqlstm.sqharm[0] = (unsigned long )0;
    sqlstm.sqadto[0] = (unsigned short )0;
    sqlstm.sqtdso[0] = (unsigned short )0;
    sqlstm.sqphsv = sqlstm.sqhstv;
    sqlstm.sqphsl = sqlstm.sqhstl;
    sqlstm.sqphss = sqlstm.sqhsts;
    sqlstm.sqpind = sqlstm.sqindv;
    sqlstm.sqpins = sqlstm.sqinds;
    sqlstm.sqparm = sqlstm.sqharm;
    sqlstm.sqparc = sqlstm.sqharc;
    sqlstm.sqpadto = sqlstm.sqadto;
    sqlstm.sqptdso = sqlstm.sqtdso;
    sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
    if (sqlca.sqlcode < 0) error_handler();
    if (sqlca.sqlwarn[0] == 'W') warning_handler();
}


    /* EXEC SQL EXECUTE stmt using :command_id; */ 

{
    struct sqlexd sqlstm;
    sqlstm.sqlvsn = 12;
    sqlstm.arrsiz = 7;
    sqlstm.sqladtp = &sqladt;
    sqlstm.sqltdsp = &sqltds;
    sqlstm.stmt = "";
    sqlstm.iters = (unsigned int  )1;
    sqlstm.offset = (unsigned int  )172;
    sqlstm.cud = sqlcud0;
    sqlstm.sqlest = (unsigned char  *)&sqlca;
    sqlstm.sqlety = (unsigned short)256;
    sqlstm.occurs = (unsigned int  )0;
    sqlstm.sqhstv[0] = (unsigned char  *)command_id;
    sqlstm.sqhstl[0] = (unsigned long )21;
    sqlstm.sqhsts[0] = (         int  )0;
    sqlstm.sqindv[0] = (         short *)0;
    sqlstm.sqinds[0] = (         int  )0;
    sqlstm.sqharm[0] = (unsigned long )0;
    sqlstm.sqadto[0] = (unsigned short )0;
    sqlstm.sqtdso[0] = (unsigned short )0;
    sqlstm.sqphsv = sqlstm.sqhstv;
    sqlstm.sqphsl = sqlstm.sqhstl;
    sqlstm.sqphss = sqlstm.sqhsts;
    sqlstm.sqpind = sqlstm.sqindv;
    sqlstm.sqpins = sqlstm.sqinds;
    sqlstm.sqparm = sqlstm.sqharm;
    sqlstm.sqparc = sqlstm.sqharc;
    sqlstm.sqpadto = sqlstm.sqadto;
    sqlstm.sqptdso = sqlstm.sqtdso;
    sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
    if (sqlca.sqlcode < 0) error_handler();
    if (sqlca.sqlwarn[0] == 'W') warning_handler();
}


    /* EXEC SQL COMMIT WORK; */ 

{
    struct sqlexd sqlstm;
    sqlstm.sqlvsn = 12;
    sqlstm.arrsiz = 7;
    sqlstm.sqladtp = &sqladt;
    sqlstm.sqltdsp = &sqltds;
    sqlstm.iters = (unsigned int  )1;
    sqlstm.offset = (unsigned int  )191;
    sqlstm.cud = sqlcud0;
    sqlstm.sqlest = (unsigned char  *)&sqlca;
    sqlstm.sqlety = (unsigned short)256;
    sqlstm.occurs = (unsigned int  )0;
    sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
    if (sqlca.sqlcode < 0) error_handler();
}



	/* ��������ձ��в����¼ */
    memset(sqlstmt, 0, sizeof(sqlstmt));
    sprintf(sqlstmt, "INSERT INTO %s VALUES(to_number(:v1),:v2,111,:v3,:v4,:v5,sysdate,'O')",backname);

    /* EXEC SQL PREPARE stmt FROM :sqlstmt; */ 

{
    struct sqlexd sqlstm;
    sqlstm.sqlvsn = 12;
    sqlstm.arrsiz = 7;
    sqlstm.sqladtp = &sqladt;
    sqlstm.sqltdsp = &sqltds;
    sqlstm.stmt = "";
    sqlstm.iters = (unsigned int  )1;
    sqlstm.offset = (unsigned int  )206;
    sqlstm.cud = sqlcud0;
    sqlstm.sqlest = (unsigned char  *)&sqlca;
    sqlstm.sqlety = (unsigned short)256;
    sqlstm.occurs = (unsigned int  )0;
    sqlstm.sqhstv[0] = (unsigned char  *)sqlstmt;
    sqlstm.sqhstl[0] = (unsigned long )513;
    sqlstm.sqhsts[0] = (         int  )0;
    sqlstm.sqindv[0] = (         short *)0;
    sqlstm.sqinds[0] = (         int  )0;
    sqlstm.sqharm[0] = (unsigned long )0;
    sqlstm.sqadto[0] = (unsigned short )0;
    sqlstm.sqtdso[0] = (unsigned short )0;
    sqlstm.sqphsv = sqlstm.sqhstv;
    sqlstm.sqphsl = sqlstm.sqhstl;
    sqlstm.sqphss = sqlstm.sqhsts;
    sqlstm.sqpind = sqlstm.sqindv;
    sqlstm.sqpins = sqlstm.sqinds;
    sqlstm.sqparm = sqlstm.sqharm;
    sqlstm.sqparc = sqlstm.sqharc;
    sqlstm.sqpadto = sqlstm.sqadto;
    sqlstm.sqptdso = sqlstm.sqtdso;
    sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
    if (sqlca.sqlcode < 0) error_handler();
    if (sqlca.sqlwarn[0] == 'W') warning_handler();
}


    /* EXEC SQL EXECUTE stmt using :command_id,:hlr_code,:phone_no,:command_code,:retcode; */ 

{
    struct sqlexd sqlstm;
    sqlstm.sqlvsn = 12;
    sqlstm.arrsiz = 7;
    sqlstm.sqladtp = &sqladt;
    sqlstm.sqltdsp = &sqltds;
    sqlstm.stmt = "";
    sqlstm.iters = (unsigned int  )1;
    sqlstm.offset = (unsigned int  )225;
    sqlstm.cud = sqlcud0;
    sqlstm.sqlest = (unsigned char  *)&sqlca;
    sqlstm.sqlety = (unsigned short)256;
    sqlstm.occurs = (unsigned int  )0;
    sqlstm.sqhstv[0] = (unsigned char  *)command_id;
    sqlstm.sqhstl[0] = (unsigned long )21;
    sqlstm.sqhsts[0] = (         int  )0;
    sqlstm.sqindv[0] = (         short *)0;
    sqlstm.sqinds[0] = (         int  )0;
    sqlstm.sqharm[0] = (unsigned long )0;
    sqlstm.sqadto[0] = (unsigned short )0;
    sqlstm.sqtdso[0] = (unsigned short )0;
    sqlstm.sqhstv[1] = (unsigned char  *)hlr_code;
    sqlstm.sqhstl[1] = (unsigned long )4;
    sqlstm.sqhsts[1] = (         int  )0;
    sqlstm.sqindv[1] = (         short *)0;
    sqlstm.sqinds[1] = (         int  )0;
    sqlstm.sqharm[1] = (unsigned long )0;
    sqlstm.sqadto[1] = (unsigned short )0;
    sqlstm.sqtdso[1] = (unsigned short )0;
    sqlstm.sqhstv[2] = (unsigned char  *)phone_no;
    sqlstm.sqhstl[2] = (unsigned long )21;
    sqlstm.sqhsts[2] = (         int  )0;
    sqlstm.sqindv[2] = (         short *)0;
    sqlstm.sqinds[2] = (         int  )0;
    sqlstm.sqharm[2] = (unsigned long )0;
    sqlstm.sqadto[2] = (unsigned short )0;
    sqlstm.sqtdso[2] = (unsigned short )0;
    sqlstm.sqhstv[3] = (unsigned char  *)command_code;
    sqlstm.sqhstl[3] = (unsigned long )8;
    sqlstm.sqhsts[3] = (         int  )0;
    sqlstm.sqindv[3] = (         short *)0;
    sqlstm.sqinds[3] = (         int  )0;
    sqlstm.sqharm[3] = (unsigned long )0;
    sqlstm.sqadto[3] = (unsigned short )0;
    sqlstm.sqtdso[3] = (unsigned short )0;
    sqlstm.sqhstv[4] = (unsigned char  *)&retcode;
    sqlstm.sqhstl[4] = (unsigned long )sizeof(int);
    sqlstm.sqhsts[4] = (         int  )0;
    sqlstm.sqindv[4] = (         short *)0;
    sqlstm.sqinds[4] = (         int  )0;
    sqlstm.sqharm[4] = (unsigned long )0;
    sqlstm.sqadto[4] = (unsigned short )0;
    sqlstm.sqtdso[4] = (unsigned short )0;
    sqlstm.sqphsv = sqlstm.sqhstv;
    sqlstm.sqphsl = sqlstm.sqhstl;
    sqlstm.sqphss = sqlstm.sqhsts;
    sqlstm.sqpind = sqlstm.sqindv;
    sqlstm.sqpins = sqlstm.sqinds;
    sqlstm.sqparm = sqlstm.sqharm;
    sqlstm.sqparc = sqlstm.sqharc;
    sqlstm.sqpadto = sqlstm.sqadto;
    sqlstm.sqptdso = sqlstm.sqtdso;
    sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
    if (sqlca.sqlcode < 0) error_handler();
    if (sqlca.sqlwarn[0] == 'W') warning_handler();
}


    if (SQLCODE != SQL_OK)
    {
		printf("sqlstmt=[%s]\n",sqlstmt);
        runflag=0;

        s_debug("write to db fail! 111 sqlstmt=[%s],retry......\n",sqlstmt);

        /* EXEC SQL COMMIT WORK; */ 

{
        struct sqlexd sqlstm;
        sqlstm.sqlvsn = 12;
        sqlstm.arrsiz = 7;
        sqlstm.sqladtp = &sqladt;
        sqlstm.sqltdsp = &sqltds;
        sqlstm.iters = (unsigned int  )1;
        sqlstm.offset = (unsigned int  )260;
        sqlstm.cud = sqlcud0;
        sqlstm.sqlest = (unsigned char  *)&sqlca;
        sqlstm.sqlety = (unsigned short)256;
        sqlstm.occurs = (unsigned int  )0;
        sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
        if (sqlca.sqlcode < 0) error_handler();
}



        sleep(60);
        /* EXEC SQL EXECUTE stmt using :command_id,:hlr_code,:phone_no,:command_code,:retcode; */ 

{
        struct sqlexd sqlstm;
        sqlstm.sqlvsn = 12;
        sqlstm.arrsiz = 7;
        sqlstm.sqladtp = &sqladt;
        sqlstm.sqltdsp = &sqltds;
        sqlstm.stmt = "";
        sqlstm.iters = (unsigned int  )1;
        sqlstm.offset = (unsigned int  )275;
        sqlstm.cud = sqlcud0;
        sqlstm.sqlest = (unsigned char  *)&sqlca;
        sqlstm.sqlety = (unsigned short)256;
        sqlstm.occurs = (unsigned int  )0;
        sqlstm.sqhstv[0] = (unsigned char  *)command_id;
        sqlstm.sqhstl[0] = (unsigned long )21;
        sqlstm.sqhsts[0] = (         int  )0;
        sqlstm.sqindv[0] = (         short *)0;
        sqlstm.sqinds[0] = (         int  )0;
        sqlstm.sqharm[0] = (unsigned long )0;
        sqlstm.sqadto[0] = (unsigned short )0;
        sqlstm.sqtdso[0] = (unsigned short )0;
        sqlstm.sqhstv[1] = (unsigned char  *)hlr_code;
        sqlstm.sqhstl[1] = (unsigned long )4;
        sqlstm.sqhsts[1] = (         int  )0;
        sqlstm.sqindv[1] = (         short *)0;
        sqlstm.sqinds[1] = (         int  )0;
        sqlstm.sqharm[1] = (unsigned long )0;
        sqlstm.sqadto[1] = (unsigned short )0;
        sqlstm.sqtdso[1] = (unsigned short )0;
        sqlstm.sqhstv[2] = (unsigned char  *)phone_no;
        sqlstm.sqhstl[2] = (unsigned long )21;
        sqlstm.sqhsts[2] = (         int  )0;
        sqlstm.sqindv[2] = (         short *)0;
        sqlstm.sqinds[2] = (         int  )0;
        sqlstm.sqharm[2] = (unsigned long )0;
        sqlstm.sqadto[2] = (unsigned short )0;
        sqlstm.sqtdso[2] = (unsigned short )0;
        sqlstm.sqhstv[3] = (unsigned char  *)command_code;
        sqlstm.sqhstl[3] = (unsigned long )8;
        sqlstm.sqhsts[3] = (         int  )0;
        sqlstm.sqindv[3] = (         short *)0;
        sqlstm.sqinds[3] = (         int  )0;
        sqlstm.sqharm[3] = (unsigned long )0;
        sqlstm.sqadto[3] = (unsigned short )0;
        sqlstm.sqtdso[3] = (unsigned short )0;
        sqlstm.sqhstv[4] = (unsigned char  *)&retcode;
        sqlstm.sqhstl[4] = (unsigned long )sizeof(int);
        sqlstm.sqhsts[4] = (         int  )0;
        sqlstm.sqindv[4] = (         short *)0;
        sqlstm.sqinds[4] = (         int  )0;
        sqlstm.sqharm[4] = (unsigned long )0;
        sqlstm.sqadto[4] = (unsigned short )0;
        sqlstm.sqtdso[4] = (unsigned short )0;
        sqlstm.sqphsv = sqlstm.sqhstv;
        sqlstm.sqphsl = sqlstm.sqhstl;
        sqlstm.sqphss = sqlstm.sqhsts;
        sqlstm.sqpind = sqlstm.sqindv;
        sqlstm.sqpins = sqlstm.sqinds;
        sqlstm.sqparm = sqlstm.sqharm;
        sqlstm.sqparc = sqlstm.sqharc;
        sqlstm.sqpadto = sqlstm.sqadto;
        sqlstm.sqptdso = sqlstm.sqtdso;
        sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
        if (sqlca.sqlcode < 0) error_handler();
        if (sqlca.sqlwarn[0] == 'W') warning_handler();
}


        if (SQLCODE != SQL_OK)
        {
            s_debug("write to db fail! 111 sqlstmt=[%s]\n",sqlstmt);

            /* EXEC SQL COMMIT WORK; */ 

{
            struct sqlexd sqlstm;
            sqlstm.sqlvsn = 12;
            sqlstm.arrsiz = 7;
            sqlstm.sqladtp = &sqladt;
            sqlstm.sqltdsp = &sqltds;
            sqlstm.iters = (unsigned int  )1;
            sqlstm.offset = (unsigned int  )310;
            sqlstm.cud = sqlcud0;
            sqlstm.sqlest = (unsigned char  *)&sqlca;
            sqlstm.sqlety = (unsigned short)256;
            sqlstm.occurs = (unsigned int  )0;
            sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
            if (sqlca.sqlcode < 0) error_handler();
}


        }
        else
        {
            runflag=3;

            printf("INSERT to db succ %s|%s!\n",command_id,phone_no);
            s_debug("INSERT to db succ %s|%s!\n",command_id,phone_no);
            /* EXEC SQL COMMIT WORK; */ 

{
            struct sqlexd sqlstm;
            sqlstm.sqlvsn = 12;
            sqlstm.arrsiz = 7;
            sqlstm.sqladtp = &sqladt;
            sqlstm.sqltdsp = &sqltds;
            sqlstm.iters = (unsigned int  )1;
            sqlstm.offset = (unsigned int  )325;
            sqlstm.cud = sqlcud0;
            sqlstm.sqlest = (unsigned char  *)&sqlca;
            sqlstm.sqlety = (unsigned short)256;
            sqlstm.occurs = (unsigned int  )0;
            sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
            if (sqlca.sqlcode < 0) error_handler();
}


        }
    }
    else
    {
        s_debug("INSERT to db succ %s|%s!\n",command_id,phone_no);
        /* EXEC SQL COMMIT WORK; */ 

{
        struct sqlexd sqlstm;
        sqlstm.sqlvsn = 12;
        sqlstm.arrsiz = 7;
        sqlstm.sqladtp = &sqladt;
        sqlstm.sqltdsp = &sqltds;
        sqlstm.iters = (unsigned int  )1;
        sqlstm.offset = (unsigned int  )340;
        sqlstm.cud = sqlcud0;
        sqlstm.sqlest = (unsigned char  *)&sqlca;
        sqlstm.sqlety = (unsigned short)256;
        sqlstm.occurs = (unsigned int  )0;
        sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
        if (sqlca.sqlcode < 0) error_handler();
}


    }

    return(1);
}

/*
int Dbclose()
{
        EXEC SQL DISCONNECT default;

	return SQLCODE;
}
*/

void error_handler()
{
	s_debug("====EXEC SQL ERROR BEGIN\n");
	s_debug("====sqlca.sqlcode=[%d],sqlca.sqlerrm.sqlerrmc=[%s]\n",\
              sqlca.sqlcode,sqlca.sqlerrm.sqlerrmc);
	s_debug("====EXEC SQL ERROR END\n");
}

void warning_handler()
{
	s_debug("----EXEC SQL WARNING BEGIN\n");
	s_debug("----sqlca.sqlcode=[%d],sqlca.sqlerrm.sqlerrmc=[%s]\n",\
              sqlca.sqlcode,sqlca.sqlerrm.sqlerrmc);
        s_debug("----EXEC SQL WARNING END\n");
}

char *delespace(char *source)
{
	int i,n;

	n=strlen(source);

	for(i=0;i<n;i++)
	{
		if(source[i]==' ')
		{
			source[i]=0x0;
			break;
		}
	}

	return source;
}


/* ȡһ������ */
int getcommand(char *sendname)
{
	memset(command_id, 0, sizeof(command_id));
	memset(command_code, 0, sizeof(command_code));
	memset(business_status,0,sizeof(business_status));
	memset(id_no, 0, sizeof(id_no));
	memset(phone_no, 0, sizeof(phone_no));
	memset(hlr_code, 0, sizeof(hlr_code));
	memset(new_phone, 0, sizeof(new_phone));
	memset(imsi_no, 0, sizeof(imsi_no));
	memset(new_imsi, 0, sizeof(new_imsi));
	memset(other_char, 0, sizeof(other_char));

	SQLCODE = SQL_OK;

	memset(tmpsql, 0, sizeof(tmpsql));
	sprintf(tmpsql, "SELECT to_char(command_id),nvl(hlr_code,''),to_char(id_no),nvl(phone_no,''),nvl(command_code,''),nvl(business_status,''),nvl(new_phone,''),nvl(imsi_no,''),nvl(new_imsi,''),nvl(other_char,'') From %s WHERE send_status='0' ",sendname);
/*
printf("CMD:%s~\n",tmpsql);
*/

	/* EXEC SQL PREPARE input_sql FROM :tmpsql; */ 

{
 struct sqlexd sqlstm;
 sqlstm.sqlvsn = 12;
 sqlstm.arrsiz = 7;
 sqlstm.sqladtp = &sqladt;
 sqlstm.sqltdsp = &sqltds;
 sqlstm.stmt = "";
 sqlstm.iters = (unsigned int  )1;
 sqlstm.offset = (unsigned int  )355;
 sqlstm.cud = sqlcud0;
 sqlstm.sqlest = (unsigned char  *)&sqlca;
 sqlstm.sqlety = (unsigned short)256;
 sqlstm.occurs = (unsigned int  )0;
 sqlstm.sqhstv[0] = (unsigned char  *)tmpsql;
 sqlstm.sqhstl[0] = (unsigned long )1025;
 sqlstm.sqhsts[0] = (         int  )0;
 sqlstm.sqindv[0] = (         short *)0;
 sqlstm.sqinds[0] = (         int  )0;
 sqlstm.sqharm[0] = (unsigned long )0;
 sqlstm.sqadto[0] = (unsigned short )0;
 sqlstm.sqtdso[0] = (unsigned short )0;
 sqlstm.sqphsv = sqlstm.sqhstv;
 sqlstm.sqphsl = sqlstm.sqhstl;
 sqlstm.sqphss = sqlstm.sqhsts;
 sqlstm.sqpind = sqlstm.sqindv;
 sqlstm.sqpins = sqlstm.sqinds;
 sqlstm.sqparm = sqlstm.sqharm;
 sqlstm.sqparc = sqlstm.sqharc;
 sqlstm.sqpadto = sqlstm.sqadto;
 sqlstm.sqptdso = sqlstm.sqtdso;
 sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
 if (sqlca.sqlcode < 0) error_handler();
 if (sqlca.sqlwarn[0] == 'W') warning_handler();
}


	/* EXEC SQL DECLARE CUR_cmd CURSOR FOR input_sql; */ 


	/* EXEC SQL OPEN CUR_cmd; */ 

{
 struct sqlexd sqlstm;
 sqlstm.sqlvsn = 12;
 sqlstm.arrsiz = 7;
 sqlstm.sqladtp = &sqladt;
 sqlstm.sqltdsp = &sqltds;
 sqlstm.stmt = "";
 sqlstm.iters = (unsigned int  )1;
 sqlstm.offset = (unsigned int  )374;
 sqlstm.selerr = (unsigned short)1;
 sqlstm.cud = sqlcud0;
 sqlstm.sqlest = (unsigned char  *)&sqlca;
 sqlstm.sqlety = (unsigned short)256;
 sqlstm.occurs = (unsigned int  )0;
 sqlstm.sqcmod = (unsigned int )0;
 sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
 if (sqlca.sqlcode < 0) error_handler();
 if (sqlca.sqlwarn[0] == 'W') warning_handler();
}


	/* EXEC SQL FETCH CUR_cmd INTO :command_id,:hlr_code,:id_no,
		:phone_no,:command_code,:business_status,:new_phone,:imsi_no,:new_imsi,:other_char; */ 

{
 struct sqlexd sqlstm;
 sqlstm.sqlvsn = 12;
 sqlstm.arrsiz = 10;
 sqlstm.sqladtp = &sqladt;
 sqlstm.sqltdsp = &sqltds;
 sqlstm.iters = (unsigned int  )1;
 sqlstm.offset = (unsigned int  )389;
 sqlstm.selerr = (unsigned short)1;
 sqlstm.cud = sqlcud0;
 sqlstm.sqlest = (unsigned char  *)&sqlca;
 sqlstm.sqlety = (unsigned short)256;
 sqlstm.occurs = (unsigned int  )0;
 sqlstm.sqfoff = (         int )0;
 sqlstm.sqfmod = (unsigned int )2;
 sqlstm.sqhstv[0] = (unsigned char  *)command_id;
 sqlstm.sqhstl[0] = (unsigned long )21;
 sqlstm.sqhsts[0] = (         int  )0;
 sqlstm.sqindv[0] = (         short *)0;
 sqlstm.sqinds[0] = (         int  )0;
 sqlstm.sqharm[0] = (unsigned long )0;
 sqlstm.sqadto[0] = (unsigned short )0;
 sqlstm.sqtdso[0] = (unsigned short )0;
 sqlstm.sqhstv[1] = (unsigned char  *)hlr_code;
 sqlstm.sqhstl[1] = (unsigned long )4;
 sqlstm.sqhsts[1] = (         int  )0;
 sqlstm.sqindv[1] = (         short *)0;
 sqlstm.sqinds[1] = (         int  )0;
 sqlstm.sqharm[1] = (unsigned long )0;
 sqlstm.sqadto[1] = (unsigned short )0;
 sqlstm.sqtdso[1] = (unsigned short )0;
 sqlstm.sqhstv[2] = (unsigned char  *)id_no;
 sqlstm.sqhstl[2] = (unsigned long )32;
 sqlstm.sqhsts[2] = (         int  )0;
 sqlstm.sqindv[2] = (         short *)0;
 sqlstm.sqinds[2] = (         int  )0;
 sqlstm.sqharm[2] = (unsigned long )0;
 sqlstm.sqadto[2] = (unsigned short )0;
 sqlstm.sqtdso[2] = (unsigned short )0;
 sqlstm.sqhstv[3] = (unsigned char  *)phone_no;
 sqlstm.sqhstl[3] = (unsigned long )21;
 sqlstm.sqhsts[3] = (         int  )0;
 sqlstm.sqindv[3] = (         short *)0;
 sqlstm.sqinds[3] = (         int  )0;
 sqlstm.sqharm[3] = (unsigned long )0;
 sqlstm.sqadto[3] = (unsigned short )0;
 sqlstm.sqtdso[3] = (unsigned short )0;
 sqlstm.sqhstv[4] = (unsigned char  *)command_code;
 sqlstm.sqhstl[4] = (unsigned long )8;
 sqlstm.sqhsts[4] = (         int  )0;
 sqlstm.sqindv[4] = (         short *)0;
 sqlstm.sqinds[4] = (         int  )0;
 sqlstm.sqharm[4] = (unsigned long )0;
 sqlstm.sqadto[4] = (unsigned short )0;
 sqlstm.sqtdso[4] = (unsigned short )0;
 sqlstm.sqhstv[5] = (unsigned char  *)business_status;
 sqlstm.sqhstl[5] = (unsigned long )8;
 sqlstm.sqhsts[5] = (         int  )0;
 sqlstm.sqindv[5] = (         short *)0;
 sqlstm.sqinds[5] = (         int  )0;
 sqlstm.sqharm[5] = (unsigned long )0;
 sqlstm.sqadto[5] = (unsigned short )0;
 sqlstm.sqtdso[5] = (unsigned short )0;
 sqlstm.sqhstv[6] = (unsigned char  *)new_phone;
 sqlstm.sqhstl[6] = (unsigned long )16;
 sqlstm.sqhsts[6] = (         int  )0;
 sqlstm.sqindv[6] = (         short *)0;
 sqlstm.sqinds[6] = (         int  )0;
 sqlstm.sqharm[6] = (unsigned long )0;
 sqlstm.sqadto[6] = (unsigned short )0;
 sqlstm.sqtdso[6] = (unsigned short )0;
 sqlstm.sqhstv[7] = (unsigned char  *)imsi_no;
 sqlstm.sqhstl[7] = (unsigned long )21;
 sqlstm.sqhsts[7] = (         int  )0;
 sqlstm.sqindv[7] = (         short *)0;
 sqlstm.sqinds[7] = (         int  )0;
 sqlstm.sqharm[7] = (unsigned long )0;
 sqlstm.sqadto[7] = (unsigned short )0;
 sqlstm.sqtdso[7] = (unsigned short )0;
 sqlstm.sqhstv[8] = (unsigned char  *)new_imsi;
 sqlstm.sqhstl[8] = (unsigned long )21;
 sqlstm.sqhsts[8] = (         int  )0;
 sqlstm.sqindv[8] = (         short *)0;
 sqlstm.sqinds[8] = (         int  )0;
 sqlstm.sqharm[8] = (unsigned long )0;
 sqlstm.sqadto[8] = (unsigned short )0;
 sqlstm.sqtdso[8] = (unsigned short )0;
 sqlstm.sqhstv[9] = (unsigned char  *)other_char;
 sqlstm.sqhstl[9] = (unsigned long )61;
 sqlstm.sqhsts[9] = (         int  )0;
 sqlstm.sqindv[9] = (         short *)0;
 sqlstm.sqinds[9] = (         int  )0;
 sqlstm.sqharm[9] = (unsigned long )0;
 sqlstm.sqadto[9] = (unsigned short )0;
 sqlstm.sqtdso[9] = (unsigned short )0;
 sqlstm.sqphsv = sqlstm.sqhstv;
 sqlstm.sqphsl = sqlstm.sqhstl;
 sqlstm.sqphss = sqlstm.sqhsts;
 sqlstm.sqpind = sqlstm.sqindv;
 sqlstm.sqpins = sqlstm.sqinds;
 sqlstm.sqparm = sqlstm.sqharm;
 sqlstm.sqparc = sqlstm.sqharc;
 sqlstm.sqpadto = sqlstm.sqadto;
 sqlstm.sqptdso = sqlstm.sqtdso;
 sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
 if (sqlca.sqlcode < 0) error_handler();
 if (sqlca.sqlwarn[0] == 'W') warning_handler();
}



	if (SQLCODE == NO_MORE_ROWS)
	{
	    /* EXEC SQL CLOSE CUR_cmd; */ 

{
     struct sqlexd sqlstm;
     sqlstm.sqlvsn = 12;
     sqlstm.arrsiz = 10;
     sqlstm.sqladtp = &sqladt;
     sqlstm.sqltdsp = &sqltds;
     sqlstm.iters = (unsigned int  )1;
     sqlstm.offset = (unsigned int  )444;
     sqlstm.cud = sqlcud0;
     sqlstm.sqlest = (unsigned char  *)&sqlca;
     sqlstm.sqlety = (unsigned short)256;
     sqlstm.occurs = (unsigned int  )0;
     sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
     if (sqlca.sqlcode < 0) error_handler();
}


	    /* EXEC SQL COMMIT WORK; */ 

{
     struct sqlexd sqlstm;
     sqlstm.sqlvsn = 12;
     sqlstm.arrsiz = 10;
     sqlstm.sqladtp = &sqladt;
     sqlstm.sqltdsp = &sqltds;
     sqlstm.iters = (unsigned int  )1;
     sqlstm.offset = (unsigned int  )459;
     sqlstm.cud = sqlcud0;
     sqlstm.sqlest = (unsigned char  *)&sqlca;
     sqlstm.sqlety = (unsigned short)256;
     sqlstm.occurs = (unsigned int  )0;
     sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
     if (sqlca.sqlcode < 0) error_handler();
}


	
	    return 0;
	}
	else if (SQLCODE != SQL_OK)
	{
        s_debug("tmpsql==[%s]\n",tmpsql);
	    /* EXEC SQL CLOSE CUR_cmd; */ 

{
     struct sqlexd sqlstm;
     sqlstm.sqlvsn = 12;
     sqlstm.arrsiz = 10;
     sqlstm.sqladtp = &sqladt;
     sqlstm.sqltdsp = &sqltds;
     sqlstm.iters = (unsigned int  )1;
     sqlstm.offset = (unsigned int  )474;
     sqlstm.cud = sqlcud0;
     sqlstm.sqlest = (unsigned char  *)&sqlca;
     sqlstm.sqlety = (unsigned short)256;
     sqlstm.occurs = (unsigned int  )0;
     sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
     if (sqlca.sqlcode < 0) error_handler();
}


	    /* EXEC SQL COMMIT WORK; */ 

{
     struct sqlexd sqlstm;
     sqlstm.sqlvsn = 12;
     sqlstm.arrsiz = 10;
     sqlstm.sqladtp = &sqladt;
     sqlstm.sqltdsp = &sqltds;
     sqlstm.iters = (unsigned int  )1;
     sqlstm.offset = (unsigned int  )489;
     sqlstm.cud = sqlcud0;
     sqlstm.sqlest = (unsigned char  *)&sqlca;
     sqlstm.sqlety = (unsigned short)256;
     sqlstm.occurs = (unsigned int  )0;
     sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
     if (sqlca.sqlcode < 0) error_handler();
}



	    return -1;
	}

    /* EXEC SQL CLOSE CUR_cmd; */ 

{
    struct sqlexd sqlstm;
    sqlstm.sqlvsn = 12;
    sqlstm.arrsiz = 10;
    sqlstm.sqladtp = &sqladt;
    sqlstm.sqltdsp = &sqltds;
    sqlstm.iters = (unsigned int  )1;
    sqlstm.offset = (unsigned int  )504;
    sqlstm.cud = sqlcud0;
    sqlstm.sqlest = (unsigned char  *)&sqlca;
    sqlstm.sqlety = (unsigned short)256;
    sqlstm.occurs = (unsigned int  )0;
    sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
    if (sqlca.sqlcode < 0) error_handler();
}


    /* EXEC SQL COMMIT WORK; */ 

{
    struct sqlexd sqlstm;
    sqlstm.sqlvsn = 12;
    sqlstm.arrsiz = 10;
    sqlstm.sqladtp = &sqladt;
    sqlstm.sqltdsp = &sqltds;
    sqlstm.iters = (unsigned int  )1;
    sqlstm.offset = (unsigned int  )519;
    sqlstm.cud = sqlcud0;
    sqlstm.sqlest = (unsigned char  *)&sqlca;
    sqlstm.sqlety = (unsigned short)256;
    sqlstm.occurs = (unsigned int  )0;
    sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
    if (sqlca.sqlcode < 0) error_handler();
}



	delspace(command_id);
	delspace(id_no);
	delspace(hlr_code);
	delspace(phone_no);
	delspace(command_code);
	delspace(business_status);
	delspace(new_phone);
	delspace(imsi_no);
	delspace(new_imsi);
	delspace(other_char);
	if(strcmp(command_code,"9a")==0||strcmp(command_code,"97")==0)/*�ƶ������ʽ�޸�*/
	{
		sprintf(phone_no,"%-20s",phone_no);
		sprintf(new_phone,"%-3s",new_phone);
		sprintf(imsi_no,"%8s",imsi_no);
		sprintf(new_imsi,"%8s",new_imsi);
		sprintf(other_char,"%s",other_char);
		printf("---------phone_no=%s\n",phone_no);
		printf("---------new_phone=%s\n",new_phone);
		printf("---------imsi_no=%s\n",imsi_no);
		printf("---------new_imsi=%s\n",new_imsi);
		printf("---------other_char=%s\n",other_char);
	}

  /*chendh������ȡ�û����� ����������*/
  if(strcmp(command_code,"24")==0||strcmp(command_code,"27")==0||strcmp(command_code,"28")==0||strcmp(command_code,"29")==0)
	{
		memset(cust_pswd,0x0,sizeof(cust_pswd));
		memset(cust_id,0x0,sizeof(cust_id));
		memset(id_no,0x0,sizeof(id_no));

		memset(tmpsql, 0, sizeof(tmpsql));
		sprintf(tmpsql, "SELECT user_passwd,to_char(cust_id),to_char(id_no) FROM dCustMsg WHERE phone_no= :v1 AND substr(run_code,2,1) < 'a' ");
		printf("CMD:%s~\n",tmpsql);

		/* EXEC SQL PREPARE input_sql FROM :tmpsql; */ 

{
  struct sqlexd sqlstm;
  sqlstm.sqlvsn = 12;
  sqlstm.arrsiz = 10;
  sqlstm.sqladtp = &sqladt;
  sqlstm.sqltdsp = &sqltds;
  sqlstm.stmt = "";
  sqlstm.iters = (unsigned int  )1;
  sqlstm.offset = (unsigned int  )534;
  sqlstm.cud = sqlcud0;
  sqlstm.sqlest = (unsigned char  *)&sqlca;
  sqlstm.sqlety = (unsigned short)256;
  sqlstm.occurs = (unsigned int  )0;
  sqlstm.sqhstv[0] = (unsigned char  *)tmpsql;
  sqlstm.sqhstl[0] = (unsigned long )1025;
  sqlstm.sqhsts[0] = (         int  )0;
  sqlstm.sqindv[0] = (         short *)0;
  sqlstm.sqinds[0] = (         int  )0;
  sqlstm.sqharm[0] = (unsigned long )0;
  sqlstm.sqadto[0] = (unsigned short )0;
  sqlstm.sqtdso[0] = (unsigned short )0;
  sqlstm.sqphsv = sqlstm.sqhstv;
  sqlstm.sqphsl = sqlstm.sqhstl;
  sqlstm.sqphss = sqlstm.sqhsts;
  sqlstm.sqpind = sqlstm.sqindv;
  sqlstm.sqpins = sqlstm.sqinds;
  sqlstm.sqparm = sqlstm.sqharm;
  sqlstm.sqparc = sqlstm.sqharc;
  sqlstm.sqpadto = sqlstm.sqadto;
  sqlstm.sqptdso = sqlstm.sqtdso;
  sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
  if (sqlca.sqlcode < 0) error_handler();
  if (sqlca.sqlwarn[0] == 'W') warning_handler();
}


		/* EXEC SQL DECLARE CUR_cmd1 CURSOR FOR input_sql; */ 


		/* EXEC SQL OPEN CUR_cmd1 using :phone_no; */ 

{
  struct sqlexd sqlstm;
  sqlstm.sqlvsn = 12;
  sqlstm.arrsiz = 10;
  sqlstm.sqladtp = &sqladt;
  sqlstm.sqltdsp = &sqltds;
  sqlstm.stmt = "";
  sqlstm.iters = (unsigned int  )1;
  sqlstm.offset = (unsigned int  )553;
  sqlstm.selerr = (unsigned short)1;
  sqlstm.cud = sqlcud0;
  sqlstm.sqlest = (unsigned char  *)&sqlca;
  sqlstm.sqlety = (unsigned short)256;
  sqlstm.occurs = (unsigned int  )0;
  sqlstm.sqcmod = (unsigned int )0;
  sqlstm.sqhstv[0] = (unsigned char  *)phone_no;
  sqlstm.sqhstl[0] = (unsigned long )21;
  sqlstm.sqhsts[0] = (         int  )0;
  sqlstm.sqindv[0] = (         short *)0;
  sqlstm.sqinds[0] = (         int  )0;
  sqlstm.sqharm[0] = (unsigned long )0;
  sqlstm.sqadto[0] = (unsigned short )0;
  sqlstm.sqtdso[0] = (unsigned short )0;
  sqlstm.sqphsv = sqlstm.sqhstv;
  sqlstm.sqphsl = sqlstm.sqhstl;
  sqlstm.sqphss = sqlstm.sqhsts;
  sqlstm.sqpind = sqlstm.sqindv;
  sqlstm.sqpins = sqlstm.sqinds;
  sqlstm.sqparm = sqlstm.sqharm;
  sqlstm.sqparc = sqlstm.sqharc;
  sqlstm.sqpadto = sqlstm.sqadto;
  sqlstm.sqptdso = sqlstm.sqtdso;
  sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
  if (sqlca.sqlcode < 0) error_handler();
  if (sqlca.sqlwarn[0] == 'W') warning_handler();
}


		/* EXEC SQL FETCH CUR_cmd1 INTO :cust_pswd,:cust_id,:id_no; */ 

{
  struct sqlexd sqlstm;
  sqlstm.sqlvsn = 12;
  sqlstm.arrsiz = 10;
  sqlstm.sqladtp = &sqladt;
  sqlstm.sqltdsp = &sqltds;
  sqlstm.iters = (unsigned int  )1;
  sqlstm.offset = (unsigned int  )572;
  sqlstm.selerr = (unsigned short)1;
  sqlstm.cud = sqlcud0;
  sqlstm.sqlest = (unsigned char  *)&sqlca;
  sqlstm.sqlety = (unsigned short)256;
  sqlstm.occurs = (unsigned int  )0;
  sqlstm.sqfoff = (         int )0;
  sqlstm.sqfmod = (unsigned int )2;
  sqlstm.sqhstv[0] = (unsigned char  *)cust_pswd;
  sqlstm.sqhstl[0] = (unsigned long )32;
  sqlstm.sqhsts[0] = (         int  )0;
  sqlstm.sqindv[0] = (         short *)0;
  sqlstm.sqinds[0] = (         int  )0;
  sqlstm.sqharm[0] = (unsigned long )0;
  sqlstm.sqadto[0] = (unsigned short )0;
  sqlstm.sqtdso[0] = (unsigned short )0;
  sqlstm.sqhstv[1] = (unsigned char  *)cust_id;
  sqlstm.sqhstl[1] = (unsigned long )32;
  sqlstm.sqhsts[1] = (         int  )0;
  sqlstm.sqindv[1] = (         short *)0;
  sqlstm.sqinds[1] = (         int  )0;
  sqlstm.sqharm[1] = (unsigned long )0;
  sqlstm.sqadto[1] = (unsigned short )0;
  sqlstm.sqtdso[1] = (unsigned short )0;
  sqlstm.sqhstv[2] = (unsigned char  *)id_no;
  sqlstm.sqhstl[2] = (unsigned long )32;
  sqlstm.sqhsts[2] = (         int  )0;
  sqlstm.sqindv[2] = (         short *)0;
  sqlstm.sqinds[2] = (         int  )0;
  sqlstm.sqharm[2] = (unsigned long )0;
  sqlstm.sqadto[2] = (unsigned short )0;
  sqlstm.sqtdso[2] = (unsigned short )0;
  sqlstm.sqphsv = sqlstm.sqhstv;
  sqlstm.sqphsl = sqlstm.sqhstl;
  sqlstm.sqphss = sqlstm.sqhsts;
  sqlstm.sqpind = sqlstm.sqindv;
  sqlstm.sqpins = sqlstm.sqinds;
  sqlstm.sqparm = sqlstm.sqharm;
  sqlstm.sqparc = sqlstm.sqharc;
  sqlstm.sqpadto = sqlstm.sqadto;
  sqlstm.sqptdso = sqlstm.sqtdso;
  sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
  if (sqlca.sqlcode < 0) error_handler();
  if (sqlca.sqlwarn[0] == 'W') warning_handler();
}



		if (SQLCODE == NO_MORE_ROWS) {
	    /* EXEC SQL CLOSE CUR_cmd1; */ 

{
     struct sqlexd sqlstm;
     sqlstm.sqlvsn = 12;
     sqlstm.arrsiz = 10;
     sqlstm.sqladtp = &sqladt;
     sqlstm.sqltdsp = &sqltds;
     sqlstm.iters = (unsigned int  )1;
     sqlstm.offset = (unsigned int  )599;
     sqlstm.cud = sqlcud0;
     sqlstm.sqlest = (unsigned char  *)&sqlca;
     sqlstm.sqlety = (unsigned short)256;
     sqlstm.occurs = (unsigned int  )0;
     sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
     if (sqlca.sqlcode < 0) error_handler();
}


	    /* EXEC SQL COMMIT WORK; */ 

{
     struct sqlexd sqlstm;
     sqlstm.sqlvsn = 12;
     sqlstm.arrsiz = 10;
     sqlstm.sqladtp = &sqladt;
     sqlstm.sqltdsp = &sqltds;
     sqlstm.iters = (unsigned int  )1;
     sqlstm.offset = (unsigned int  )614;
     sqlstm.cud = sqlcud0;
     sqlstm.sqlest = (unsigned char  *)&sqlca;
     sqlstm.sqlety = (unsigned short)256;
     sqlstm.occurs = (unsigned int  )0;
     sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
     if (sqlca.sqlcode < 0) error_handler();
}


	
	    return 3991;
		}
		else if (SQLCODE != SQL_OK)
		{
			s_debug("tmpsql==[%s]\n",tmpsql);
			/* EXEC SQL CLOSE CUR_cmd1; */ 

{
   struct sqlexd sqlstm;
   sqlstm.sqlvsn = 12;
   sqlstm.arrsiz = 10;
   sqlstm.sqladtp = &sqladt;
   sqlstm.sqltdsp = &sqltds;
   sqlstm.iters = (unsigned int  )1;
   sqlstm.offset = (unsigned int  )629;
   sqlstm.cud = sqlcud0;
   sqlstm.sqlest = (unsigned char  *)&sqlca;
   sqlstm.sqlety = (unsigned short)256;
   sqlstm.occurs = (unsigned int  )0;
   sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
   if (sqlca.sqlcode < 0) error_handler();
}


			/* EXEC SQL COMMIT WORK; */ 

{
   struct sqlexd sqlstm;
   sqlstm.sqlvsn = 12;
   sqlstm.arrsiz = 10;
   sqlstm.sqladtp = &sqladt;
   sqlstm.sqltdsp = &sqltds;
   sqlstm.iters = (unsigned int  )1;
   sqlstm.offset = (unsigned int  )644;
   sqlstm.cud = sqlcud0;
   sqlstm.sqlest = (unsigned char  *)&sqlca;
   sqlstm.sqlety = (unsigned short)256;
   sqlstm.occurs = (unsigned int  )0;
   sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
   if (sqlca.sqlcode < 0) error_handler();
}



			return -1;
		}
    /* EXEC SQL CLOSE CUR_cmd1; */ 

{
    struct sqlexd sqlstm;
    sqlstm.sqlvsn = 12;
    sqlstm.arrsiz = 10;
    sqlstm.sqladtp = &sqladt;
    sqlstm.sqltdsp = &sqltds;
    sqlstm.iters = (unsigned int  )1;
    sqlstm.offset = (unsigned int  )659;
    sqlstm.cud = sqlcud0;
    sqlstm.sqlest = (unsigned char  *)&sqlca;
    sqlstm.sqlety = (unsigned short)256;
    sqlstm.occurs = (unsigned int  )0;
    sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
    if (sqlca.sqlcode < 0) error_handler();
}


    /* EXEC SQL COMMIT WORK; */ 

{
    struct sqlexd sqlstm;
    sqlstm.sqlvsn = 12;
    sqlstm.arrsiz = 10;
    sqlstm.sqladtp = &sqladt;
    sqlstm.sqltdsp = &sqltds;
    sqlstm.iters = (unsigned int  )1;
    sqlstm.offset = (unsigned int  )674;
    sqlstm.cud = sqlcud0;
    sqlstm.sqlest = (unsigned char  *)&sqlca;
    sqlstm.sqlety = (unsigned short)256;
    sqlstm.occurs = (unsigned int  )0;
    sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
    if (sqlca.sqlcode < 0) error_handler();
}



		delspace(cust_pswd);
		
		if(strlen(cust_pswd)!=0)
		{	
			ret=unencrypt(cust_pswd,dest_pswd,ENCRYPTKEY,"1");
			if(ret!=0)	
				return 3994;
		}
		else
		{
			strcpy(dest_pswd,cust_pswd);
		}	
		/*
		unencrypt(cust_pswd,dest_pswd);
		*/
		delspace(cust_id);
		delspace(id_no);

		memset(cust_name,0x0,sizeof(cust_name));

		memset(tmpsql, 0, sizeof(tmpsql));
		sprintf(tmpsql, "SELECT cust_name FROM dCustDoc WHERE cust_id=to_number(:v1) ");
		printf("CMD:%s~\n",tmpsql);

		/* EXEC SQL PREPARE input_sql FROM :tmpsql; */ 

{
  struct sqlexd sqlstm;
  sqlstm.sqlvsn = 12;
  sqlstm.arrsiz = 10;
  sqlstm.sqladtp = &sqladt;
  sqlstm.sqltdsp = &sqltds;
  sqlstm.stmt = "";
  sqlstm.iters = (unsigned int  )1;
  sqlstm.offset = (unsigned int  )689;
  sqlstm.cud = sqlcud0;
  sqlstm.sqlest = (unsigned char  *)&sqlca;
  sqlstm.sqlety = (unsigned short)256;
  sqlstm.occurs = (unsigned int  )0;
  sqlstm.sqhstv[0] = (unsigned char  *)tmpsql;
  sqlstm.sqhstl[0] = (unsigned long )1025;
  sqlstm.sqhsts[0] = (         int  )0;
  sqlstm.sqindv[0] = (         short *)0;
  sqlstm.sqinds[0] = (         int  )0;
  sqlstm.sqharm[0] = (unsigned long )0;
  sqlstm.sqadto[0] = (unsigned short )0;
  sqlstm.sqtdso[0] = (unsigned short )0;
  sqlstm.sqphsv = sqlstm.sqhstv;
  sqlstm.sqphsl = sqlstm.sqhstl;
  sqlstm.sqphss = sqlstm.sqhsts;
  sqlstm.sqpind = sqlstm.sqindv;
  sqlstm.sqpins = sqlstm.sqinds;
  sqlstm.sqparm = sqlstm.sqharm;
  sqlstm.sqparc = sqlstm.sqharc;
  sqlstm.sqpadto = sqlstm.sqadto;
  sqlstm.sqptdso = sqlstm.sqtdso;
  sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
  if (sqlca.sqlcode < 0) error_handler();
  if (sqlca.sqlwarn[0] == 'W') warning_handler();
}


		/* EXEC SQL DECLARE CUR_cmd2 CURSOR FOR input_sql; */ 


		/* EXEC SQL OPEN CUR_cmd2 using :cust_id; */ 

{
  struct sqlexd sqlstm;
  sqlstm.sqlvsn = 12;
  sqlstm.arrsiz = 10;
  sqlstm.sqladtp = &sqladt;
  sqlstm.sqltdsp = &sqltds;
  sqlstm.stmt = "";
  sqlstm.iters = (unsigned int  )1;
  sqlstm.offset = (unsigned int  )708;
  sqlstm.selerr = (unsigned short)1;
  sqlstm.cud = sqlcud0;
  sqlstm.sqlest = (unsigned char  *)&sqlca;
  sqlstm.sqlety = (unsigned short)256;
  sqlstm.occurs = (unsigned int  )0;
  sqlstm.sqcmod = (unsigned int )0;
  sqlstm.sqhstv[0] = (unsigned char  *)cust_id;
  sqlstm.sqhstl[0] = (unsigned long )32;
  sqlstm.sqhsts[0] = (         int  )0;
  sqlstm.sqindv[0] = (         short *)0;
  sqlstm.sqinds[0] = (         int  )0;
  sqlstm.sqharm[0] = (unsigned long )0;
  sqlstm.sqadto[0] = (unsigned short )0;
  sqlstm.sqtdso[0] = (unsigned short )0;
  sqlstm.sqphsv = sqlstm.sqhstv;
  sqlstm.sqphsl = sqlstm.sqhstl;
  sqlstm.sqphss = sqlstm.sqhsts;
  sqlstm.sqpind = sqlstm.sqindv;
  sqlstm.sqpins = sqlstm.sqinds;
  sqlstm.sqparm = sqlstm.sqharm;
  sqlstm.sqparc = sqlstm.sqharc;
  sqlstm.sqpadto = sqlstm.sqadto;
  sqlstm.sqptdso = sqlstm.sqtdso;
  sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
  if (sqlca.sqlcode < 0) error_handler();
  if (sqlca.sqlwarn[0] == 'W') warning_handler();
}


		/* EXEC SQL FETCH CUR_cmd2 INTO :cust_name; */ 

{
  struct sqlexd sqlstm;
  sqlstm.sqlvsn = 12;
  sqlstm.arrsiz = 10;
  sqlstm.sqladtp = &sqladt;
  sqlstm.sqltdsp = &sqltds;
  sqlstm.iters = (unsigned int  )1;
  sqlstm.offset = (unsigned int  )727;
  sqlstm.selerr = (unsigned short)1;
  sqlstm.cud = sqlcud0;
  sqlstm.sqlest = (unsigned char  *)&sqlca;
  sqlstm.sqlety = (unsigned short)256;
  sqlstm.occurs = (unsigned int  )0;
  sqlstm.sqfoff = (         int )0;
  sqlstm.sqfmod = (unsigned int )2;
  sqlstm.sqhstv[0] = (unsigned char  *)cust_name;
  sqlstm.sqhstl[0] = (unsigned long )61;
  sqlstm.sqhsts[0] = (         int  )0;
  sqlstm.sqindv[0] = (         short *)0;
  sqlstm.sqinds[0] = (         int  )0;
  sqlstm.sqharm[0] = (unsigned long )0;
  sqlstm.sqadto[0] = (unsigned short )0;
  sqlstm.sqtdso[0] = (unsigned short )0;
  sqlstm.sqphsv = sqlstm.sqhstv;
  sqlstm.sqphsl = sqlstm.sqhstl;
  sqlstm.sqphss = sqlstm.sqhsts;
  sqlstm.sqpind = sqlstm.sqindv;
  sqlstm.sqpins = sqlstm.sqinds;
  sqlstm.sqparm = sqlstm.sqharm;
  sqlstm.sqparc = sqlstm.sqharc;
  sqlstm.sqpadto = sqlstm.sqadto;
  sqlstm.sqptdso = sqlstm.sqtdso;
  sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
  if (sqlca.sqlcode < 0) error_handler();
  if (sqlca.sqlwarn[0] == 'W') warning_handler();
}



		if (SQLCODE == NO_MORE_ROWS) {
	    /* EXEC SQL CLOSE CUR_cmd2; */ 

{
     struct sqlexd sqlstm;
     sqlstm.sqlvsn = 12;
     sqlstm.arrsiz = 10;
     sqlstm.sqladtp = &sqladt;
     sqlstm.sqltdsp = &sqltds;
     sqlstm.iters = (unsigned int  )1;
     sqlstm.offset = (unsigned int  )746;
     sqlstm.cud = sqlcud0;
     sqlstm.sqlest = (unsigned char  *)&sqlca;
     sqlstm.sqlety = (unsigned short)256;
     sqlstm.occurs = (unsigned int  )0;
     sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
     if (sqlca.sqlcode < 0) error_handler();
}


	    /* EXEC SQL COMMIT WORK; */ 

{
     struct sqlexd sqlstm;
     sqlstm.sqlvsn = 12;
     sqlstm.arrsiz = 10;
     sqlstm.sqladtp = &sqladt;
     sqlstm.sqltdsp = &sqltds;
     sqlstm.iters = (unsigned int  )1;
     sqlstm.offset = (unsigned int  )761;
     sqlstm.cud = sqlcud0;
     sqlstm.sqlest = (unsigned char  *)&sqlca;
     sqlstm.sqlety = (unsigned short)256;
     sqlstm.occurs = (unsigned int  )0;
     sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
     if (sqlca.sqlcode < 0) error_handler();
}


	
	    return 3992;
		}
		else if (SQLCODE != SQL_OK)
		{
  	   	s_debug("tmpsql==[%s]\n",tmpsql);
	    /* EXEC SQL CLOSE CUR_cmd2; */ 

{
     struct sqlexd sqlstm;
     sqlstm.sqlvsn = 12;
     sqlstm.arrsiz = 10;
     sqlstm.sqladtp = &sqladt;
     sqlstm.sqltdsp = &sqltds;
     sqlstm.iters = (unsigned int  )1;
     sqlstm.offset = (unsigned int  )776;
     sqlstm.cud = sqlcud0;
     sqlstm.sqlest = (unsigned char  *)&sqlca;
     sqlstm.sqlety = (unsigned short)256;
     sqlstm.occurs = (unsigned int  )0;
     sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
     if (sqlca.sqlcode < 0) error_handler();
}


	    /* EXEC SQL COMMIT WORK; */ 

{
     struct sqlexd sqlstm;
     sqlstm.sqlvsn = 12;
     sqlstm.arrsiz = 10;
     sqlstm.sqladtp = &sqladt;
     sqlstm.sqltdsp = &sqltds;
     sqlstm.iters = (unsigned int  )1;
     sqlstm.offset = (unsigned int  )791;
     sqlstm.cud = sqlcud0;
     sqlstm.sqlest = (unsigned char  *)&sqlca;
     sqlstm.sqlety = (unsigned short)256;
     sqlstm.occurs = (unsigned int  )0;
     sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
     if (sqlca.sqlcode < 0) error_handler();
}



	    return -1;
		}
    /* EXEC SQL CLOSE CUR_cmd2; */ 

{
    struct sqlexd sqlstm;
    sqlstm.sqlvsn = 12;
    sqlstm.arrsiz = 10;
    sqlstm.sqladtp = &sqladt;
    sqlstm.sqltdsp = &sqltds;
    sqlstm.iters = (unsigned int  )1;
    sqlstm.offset = (unsigned int  )806;
    sqlstm.cud = sqlcud0;
    sqlstm.sqlest = (unsigned char  *)&sqlca;
    sqlstm.sqlety = (unsigned short)256;
    sqlstm.occurs = (unsigned int  )0;
    sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
    if (sqlca.sqlcode < 0) error_handler();
}


    /* EXEC SQL COMMIT WORK; */ 

{
    struct sqlexd sqlstm;
    sqlstm.sqlvsn = 12;
    sqlstm.arrsiz = 10;
    sqlstm.sqladtp = &sqladt;
    sqlstm.sqltdsp = &sqltds;
    sqlstm.iters = (unsigned int  )1;
    sqlstm.offset = (unsigned int  )821;
    sqlstm.cud = sqlcud0;
    sqlstm.sqlest = (unsigned char  *)&sqlca;
    sqlstm.sqlety = (unsigned short)256;
    sqlstm.occurs = (unsigned int  )0;
    sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
    if (sqlca.sqlcode < 0) error_handler();
}



		delspace(cust_name);

		if(strcmp(command_code,"24")==0)
			return 1;

		if(strcmp(command_code,"29")==0 && atoi(business_status)==1)
			return 1;
	
		/*��ָ������������ʱ����JGF20051229*/			
		if(strcmp(command_code,"27")==0)
			return 1;

		memset(add_no,0x0,sizeof(add_no));
	
		if(strcmp(command_code,"28")==0 && atoi(business_status)==1)
		{
		memset(tmpsql, 0, sizeof(tmpsql));
		sprintf(tmpsql, "SELECT add_no FROM dCustFuncAdd WHERE function_code ='27' and id_no= to_number(:v1) ");
printf("CMD:%s~\n",tmpsql);
	
		/* EXEC SQL PREPARE input_sql FROM :tmpsql; */ 

{
  struct sqlexd sqlstm;
  sqlstm.sqlvsn = 12;
  sqlstm.arrsiz = 10;
  sqlstm.sqladtp = &sqladt;
  sqlstm.sqltdsp = &sqltds;
  sqlstm.stmt = "";
  sqlstm.iters = (unsigned int  )1;
  sqlstm.offset = (unsigned int  )836;
  sqlstm.cud = sqlcud0;
  sqlstm.sqlest = (unsigned char  *)&sqlca;
  sqlstm.sqlety = (unsigned short)256;
  sqlstm.occurs = (unsigned int  )0;
  sqlstm.sqhstv[0] = (unsigned char  *)tmpsql;
  sqlstm.sqhstl[0] = (unsigned long )1025;
  sqlstm.sqhsts[0] = (         int  )0;
  sqlstm.sqindv[0] = (         short *)0;
  sqlstm.sqinds[0] = (         int  )0;
  sqlstm.sqharm[0] = (unsigned long )0;
  sqlstm.sqadto[0] = (unsigned short )0;
  sqlstm.sqtdso[0] = (unsigned short )0;
  sqlstm.sqphsv = sqlstm.sqhstv;
  sqlstm.sqphsl = sqlstm.sqhstl;
  sqlstm.sqphss = sqlstm.sqhsts;
  sqlstm.sqpind = sqlstm.sqindv;
  sqlstm.sqpins = sqlstm.sqinds;
  sqlstm.sqparm = sqlstm.sqharm;
  sqlstm.sqparc = sqlstm.sqharc;
  sqlstm.sqpadto = sqlstm.sqadto;
  sqlstm.sqptdso = sqlstm.sqtdso;
  sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
  if (sqlca.sqlcode < 0) error_handler();
  if (sqlca.sqlwarn[0] == 'W') warning_handler();
}


		/* EXEC SQL DECLARE CUR_cmd3 CURSOR FOR input_sql; */ 

	
		/* EXEC SQL OPEN CUR_cmd3 using :id_no; */ 

{
  struct sqlexd sqlstm;
  sqlstm.sqlvsn = 12;
  sqlstm.arrsiz = 10;
  sqlstm.sqladtp = &sqladt;
  sqlstm.sqltdsp = &sqltds;
  sqlstm.stmt = "";
  sqlstm.iters = (unsigned int  )1;
  sqlstm.offset = (unsigned int  )855;
  sqlstm.selerr = (unsigned short)1;
  sqlstm.cud = sqlcud0;
  sqlstm.sqlest = (unsigned char  *)&sqlca;
  sqlstm.sqlety = (unsigned short)256;
  sqlstm.occurs = (unsigned int  )0;
  sqlstm.sqcmod = (unsigned int )0;
  sqlstm.sqhstv[0] = (unsigned char  *)id_no;
  sqlstm.sqhstl[0] = (unsigned long )32;
  sqlstm.sqhsts[0] = (         int  )0;
  sqlstm.sqindv[0] = (         short *)0;
  sqlstm.sqinds[0] = (         int  )0;
  sqlstm.sqharm[0] = (unsigned long )0;
  sqlstm.sqadto[0] = (unsigned short )0;
  sqlstm.sqtdso[0] = (unsigned short )0;
  sqlstm.sqphsv = sqlstm.sqhstv;
  sqlstm.sqphsl = sqlstm.sqhstl;
  sqlstm.sqphss = sqlstm.sqhsts;
  sqlstm.sqpind = sqlstm.sqindv;
  sqlstm.sqpins = sqlstm.sqinds;
  sqlstm.sqparm = sqlstm.sqharm;
  sqlstm.sqparc = sqlstm.sqharc;
  sqlstm.sqpadto = sqlstm.sqadto;
  sqlstm.sqptdso = sqlstm.sqtdso;
  sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
  if (sqlca.sqlcode < 0) error_handler();
  if (sqlca.sqlwarn[0] == 'W') warning_handler();
}


		/* EXEC SQL FETCH CUR_cmd3 INTO :add_no; */ 

{
  struct sqlexd sqlstm;
  sqlstm.sqlvsn = 12;
  sqlstm.arrsiz = 10;
  sqlstm.sqladtp = &sqladt;
  sqlstm.sqltdsp = &sqltds;
  sqlstm.iters = (unsigned int  )1;
  sqlstm.offset = (unsigned int  )874;
  sqlstm.selerr = (unsigned short)1;
  sqlstm.cud = sqlcud0;
  sqlstm.sqlest = (unsigned char  *)&sqlca;
  sqlstm.sqlety = (unsigned short)256;
  sqlstm.occurs = (unsigned int  )0;
  sqlstm.sqfoff = (         int )0;
  sqlstm.sqfmod = (unsigned int )2;
  sqlstm.sqhstv[0] = (unsigned char  *)add_no;
  sqlstm.sqhstl[0] = (unsigned long )32;
  sqlstm.sqhsts[0] = (         int  )0;
  sqlstm.sqindv[0] = (         short *)0;
  sqlstm.sqinds[0] = (         int  )0;
  sqlstm.sqharm[0] = (unsigned long )0;
  sqlstm.sqadto[0] = (unsigned short )0;
  sqlstm.sqtdso[0] = (unsigned short )0;
  sqlstm.sqphsv = sqlstm.sqhstv;
  sqlstm.sqphsl = sqlstm.sqhstl;
  sqlstm.sqphss = sqlstm.sqhsts;
  sqlstm.sqpind = sqlstm.sqindv;
  sqlstm.sqpins = sqlstm.sqinds;
  sqlstm.sqparm = sqlstm.sqharm;
  sqlstm.sqparc = sqlstm.sqharc;
  sqlstm.sqpadto = sqlstm.sqadto;
  sqlstm.sqptdso = sqlstm.sqtdso;
  sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
  if (sqlca.sqlcode < 0) error_handler();
  if (sqlca.sqlwarn[0] == 'W') warning_handler();
}


	
		if (SQLCODE == NO_MORE_ROWS) {
		    /* EXEC SQL CLOSE CUR_cmd3; */ 

{
      struct sqlexd sqlstm;
      sqlstm.sqlvsn = 12;
      sqlstm.arrsiz = 10;
      sqlstm.sqladtp = &sqladt;
      sqlstm.sqltdsp = &sqltds;
      sqlstm.iters = (unsigned int  )1;
      sqlstm.offset = (unsigned int  )893;
      sqlstm.cud = sqlcud0;
      sqlstm.sqlest = (unsigned char  *)&sqlca;
      sqlstm.sqlety = (unsigned short)256;
      sqlstm.occurs = (unsigned int  )0;
      sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
      if (sqlca.sqlcode < 0) error_handler();
}


		    /* EXEC SQL COMMIT WORK; */ 

{
      struct sqlexd sqlstm;
      sqlstm.sqlvsn = 12;
      sqlstm.arrsiz = 10;
      sqlstm.sqladtp = &sqladt;
      sqlstm.sqltdsp = &sqltds;
      sqlstm.iters = (unsigned int  )1;
      sqlstm.offset = (unsigned int  )908;
      sqlstm.cud = sqlcud0;
      sqlstm.sqlest = (unsigned char  *)&sqlca;
      sqlstm.sqlety = (unsigned short)256;
      sqlstm.occurs = (unsigned int  )0;
      sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
      if (sqlca.sqlcode < 0) error_handler();
}


		    strcpy(add_no,"");
	/*	    strcpy(add_no,"z10120013659986");		    		
		    return 3993;*/
		}
		else if (SQLCODE != SQL_OK)
		{
	  	    s_debug("tmpsql==[%s]\n",tmpsql);
		    /* EXEC SQL CLOSE CUR_cmd3; */ 

{
      struct sqlexd sqlstm;
      sqlstm.sqlvsn = 12;
      sqlstm.arrsiz = 10;
      sqlstm.sqladtp = &sqladt;
      sqlstm.sqltdsp = &sqltds;
      sqlstm.iters = (unsigned int  )1;
      sqlstm.offset = (unsigned int  )923;
      sqlstm.cud = sqlcud0;
      sqlstm.sqlest = (unsigned char  *)&sqlca;
      sqlstm.sqlety = (unsigned short)256;
      sqlstm.occurs = (unsigned int  )0;
      sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
      if (sqlca.sqlcode < 0) error_handler();
}


		    /* EXEC SQL COMMIT WORK; */ 

{
      struct sqlexd sqlstm;
      sqlstm.sqlvsn = 12;
      sqlstm.arrsiz = 10;
      sqlstm.sqladtp = &sqladt;
      sqlstm.sqltdsp = &sqltds;
      sqlstm.iters = (unsigned int  )1;
      sqlstm.offset = (unsigned int  )938;
      sqlstm.cud = sqlcud0;
      sqlstm.sqlest = (unsigned char  *)&sqlca;
      sqlstm.sqlety = (unsigned short)256;
      sqlstm.occurs = (unsigned int  )0;
      sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
      if (sqlca.sqlcode < 0) error_handler();
}


	
		    return -1;
		}
		
		/* EXEC SQL CLOSE CUR_cmd3; */ 

{
  struct sqlexd sqlstm;
  sqlstm.sqlvsn = 12;
  sqlstm.arrsiz = 10;
  sqlstm.sqladtp = &sqladt;
  sqlstm.sqltdsp = &sqltds;
  sqlstm.iters = (unsigned int  )1;
  sqlstm.offset = (unsigned int  )953;
  sqlstm.cud = sqlcud0;
  sqlstm.sqlest = (unsigned char  *)&sqlca;
  sqlstm.sqlety = (unsigned short)256;
  sqlstm.occurs = (unsigned int  )0;
  sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
  if (sqlca.sqlcode < 0) error_handler();
}


		/* EXEC SQL COMMIT WORK; */ 

{
  struct sqlexd sqlstm;
  sqlstm.sqlvsn = 12;
  sqlstm.arrsiz = 10;
  sqlstm.sqladtp = &sqladt;
  sqlstm.sqltdsp = &sqltds;
  sqlstm.iters = (unsigned int  )1;
  sqlstm.offset = (unsigned int  )968;
  sqlstm.cud = sqlcud0;
  sqlstm.sqlest = (unsigned char  *)&sqlca;
  sqlstm.sqlety = (unsigned short)256;
  sqlstm.occurs = (unsigned int  )0;
  sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
  if (sqlca.sqlcode < 0) error_handler();
}



		delspace(add_no);	
		}
	}

    return 1;
}

void  IgnoreAllSignal();

int
GenDaemon()
{
int childpid,fd;
int flag;

	if (getppid()==1) {
		chdir ("/");
		umask(0);
		IgnoreAllSignal();
		return 0;
	}
	
	IgnoreAllSignal();
	if ((childpid = fork())<0 ) {
		s_debug("can't fork first child %s %d\n",__FILE__,__LINE__);
		exit(-1);
	}
	else
		if (childpid > 0)
			exit(0);
	/*---if ((flag=setpgrp()) == -1) {
		s_debug("set process group err %s %d\n",__FILE__,__LINE__);
		exit(-2);
	}----*/

	IgnoreAllSignal();
	if ((childpid = fork()) < 0) {
		s_debug("can't fork fist child %s %d\n",__FILE__,__LINE__);
		exit(-3);
	}
	else 
		if (childpid > 0)
			exit(0);

	for (fd=3; fd<=SNOFILE;fd++)
		close (fd);
	
	chdir("/");
	umask(0);
	IgnoreAllSignal();
	return 0;
}



void
IgnoreAllSignal()
{
struct sigaction act;

	act.sa_handler = SIG_IGN;
	sigemptyset(&act.sa_mask);
	act.sa_flags=0;
	sigaction(SIGHUP,&act,NULL);
	sigaction(SIGCHLD,&act,NULL); 
	sigaction(SIGQUIT,&act,NULL);
	
	return ;
}

void LogOut(int sig)
{
	s_debug("process is killed\n");
	exit(1);
}

