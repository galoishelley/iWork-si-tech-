
/* Result Sets Interface */
#ifndef SQL_CRSR
#  define SQL_CRSR
  struct sql_cursor
  {
    unsigned int curocn;
    void *ptr1;
    void *ptr2;
    unsigned int magic;
  };
  typedef struct sql_cursor sql_cursor;
  typedef struct sql_cursor SQL_CURSOR;
#endif /* SQL_CRSR */

/* Thread Safety */
typedef void * sql_context;
typedef void * SQL_CONTEXT;

/* Object support */
struct sqltvn
{
  unsigned char *tvnvsn; 
  unsigned short tvnvsnl; 
  unsigned char *tvnnm;
  unsigned short tvnnml; 
  unsigned char *tvnsnm;
  unsigned short tvnsnml;
};
typedef struct sqltvn sqltvn;

struct sqladts
{
  unsigned int adtvsn; 
  unsigned short adtmode; 
  unsigned short adtnum;  
  sqltvn adttvn[1];       
};
typedef struct sqladts sqladts;

static struct sqladts sqladt = {
  1,1,0,
};

/* Binding to PL/SQL Records */
struct sqltdss
{
  unsigned int tdsvsn; 
  unsigned short tdsnum; 
  unsigned char *tdsval[1]; 
};
typedef struct sqltdss sqltdss;
static struct sqltdss sqltds =
{
  1,
  0,
};

/* File name & Package Name */
struct sqlcxp
{
  unsigned short fillen;
           char  filnam[15];
};
static struct sqlcxp sqlfpn =
{
    14,
    "datasmsgreq.pc"
};


static unsigned int sqlctx = 1144051;


static struct sqlexd {
   unsigned long  sqlvsn;
   unsigned int   arrsiz;
   unsigned int   iters;
   unsigned int   offset;
   unsigned short selerr;
   unsigned short sqlety;
   unsigned int   occurs;
            short *cud;
   unsigned char  *sqlest;
            char  *stmt;
   sqladts *sqladtp;
   sqltdss *sqltdsp;
   unsigned char  **sqphsv;
   unsigned long  *sqphsl;
            int   *sqphss;
            short **sqpind;
            int   *sqpins;
   unsigned long  *sqparm;
   unsigned long  **sqparc;
   unsigned short  *sqpadto;
   unsigned short  *sqptdso;
   unsigned int   sqlcmax;
   unsigned int   sqlcmin;
   unsigned int   sqlcincr;
   unsigned int   sqlctimeout;
   unsigned int   sqlcnowait;
            int   sqfoff;
   unsigned int   sqcmod;
   unsigned int   sqfmod;
   unsigned char  *sqhstv[1];
   unsigned long  sqhstl[1];
            int   sqhsts[1];
            short *sqindv[1];
            int   sqinds[1];
   unsigned long  sqharm[1];
   unsigned long  *sqharc[1];
   unsigned short  sqadto[1];
   unsigned short  sqtdso[1];
} sqlstm = {12,1};

/* SQLLIB Prototypes */
extern sqlcxt (/*_ void **, unsigned int *,
                   struct sqlexd *, struct sqlcxp * _*/);
extern sqlcx2t(/*_ void **, unsigned int *,
                   struct sqlexd *, struct sqlcxp * _*/);
extern sqlbuft(/*_ void **, char * _*/);
extern sqlgs2t(/*_ void **, char * _*/);
extern sqlorat(/*_ void **, unsigned int *, void * _*/);

/* Forms Interface */
static int IAPSUCC = 0;
static int IAPFAIL = 1403;
static int IAPFTL  = 535;
extern void sqliem(/*_ char *, int * _*/);

typedef struct { unsigned short len; unsigned char arr[1]; } VARCHAR;
typedef struct { unsigned short len; unsigned char arr[1]; } varchar;

/* CUD (Compilation Unit Data) Array */
static short sqlcud0[] =
{12,4130,852,0,0,
};


#include "onoff.h"
#include "datacenter.h"
#include <sqlca.h>
#include <onoff.h>
#include <db_func.h>
#include <sys/stat.h>

#define MAX_TIME_OUT    180
#define MSGHEAD_LEN     105
#define MSG_LEN     	
#define  MAX_LENGTH   1024 
#define	MAX_PRCS    10
#define  LABELPOSTURL        "posturl"
#define  POSTURL   "POST /dcs/BOSS HTTP/1.1\n"
#define SPRI        "/"
#define CFGDIR      "/cfg"
#define COMMENT         '#'
#define DXHZCFG   "dxhz.cfg"
#define LINE            120
#define  httpHead_len  10
static int  sigFlag;
static int  sockFD;
void LogOut();
void sigProcess(int signo)
{
		sigFlag = 1;
		close(signo);
		return;
}
typedef struct msgHead
{
    char msgflag[4+1];
	char msgtype[1+1];
	char servtype[15+1];
	char username[10+1];
    char userpswd[10+1];
    char msgno[16+1];
    char reserved[16+1];
    char mobile[20+1];
    char begintime[14+1];
}
tMsgHead ;
/*��Ϣ�ṹ����*/
typedef struct msgBody
{
    char content[1024*10+1];
}
tMsgBody ;
typedef struct transMsg
{
    tMsgHead vMsgHead ;
    tMsgBody vMsgBody ;
    char accept[14+1];
    char opTime[17+1];
}
TransMsg ;
struct dxhz_cfg {
    char ipaddr[20];
    char portno[10];
};
struct dxhz_cfg dxhzcfg[MAX_PRCS];

int retcode;
int TimeOut;

void catchalm(sig)
int sig;
{
  signal(sig,SIG_IGN);
  TimeOut=1;

  return;
}


int main(int argc,char **argv)
{
	int i,n,sockid;
	struct sockaddr_in srv_addr, cli_addr;
	int subsockid,opt,len,pid,vPort,count;
	int  clilen, iRecvMsgLen, iSendLength, retCode=0,connFlag=0,sigFlag;
	int	 httpCode,rcvLength;
	char    vMsgHead[MSGHEAD_LEN+1];
	char      recvline[MAX_LENGTH];
	char	*p,*q;
	FILE *fp;
	char  pTmpFile[1024*2+1];
	char	return_code[6+1];
	char	vMsgBuff[1024*2+1];
	char	msgBuffer[1024*10+1];
	char	vRspMsg[1024*2+1];
	char	vmsgtype[15+1];
	char	vFindStr[9+1];
	TransMsg	vTransMsg;
	/*�����������*/
	if(argc!=2)
	{
		printf("Usage:datasmsgreq port(40000 < port < 60000)\n");
		exit(1);
	}
	vPort = atoi(argv[1]);
	printf("����Ĳ���Ϊ[%d]\n",vPort);
	/*
	signal(SIGPIPE,SIG_IGN);
    signal(SIGCLD,SIG_IGN);
    signal(SIGINT,SIG_IGN);
    signal(SIGALRM,catchalm);
    */
	if(signal(SIGALRM,sigProcess) == SIG_ERR)
    {
        return(1000);
    }
    alarm(180);
    alarm(MAX_TIME_OUT);
	
    /* SOCKET�������� */
    sockid = socket(AF_INET,SOCK_STREAM,0);
    if(sockid < 0)
    {
        printf("Error: socket() failed[%d]\n",errno);
        exit(1);
    }
    memset(vFindStr,'\0',sizeof(vFindStr));
    memset(recvline,'\0',sizeof(recvline));
    memset(vRspMsg,'\0',sizeof(vRspMsg));
    memset(return_code,'\0',sizeof(return_code));
    memset(vmsgtype,0x0,sizeof(vmsgtype));
	memset(vMsgBuff,0x0,sizeof(vMsgBuff));
    memset(&srv_addr, 0x0, sizeof(srv_addr));
    srv_addr.sin_family = AF_INET;
    srv_addr.sin_addr.s_addr = 0;
    srv_addr.sin_port = htons(vPort);
	opt=1;
    len=sizeof(opt);
    setsockopt(sockid, SOL_SOCKET, SO_REUSEADDR, (void *)&opt, len);
    if(bind(sockid, (struct sockaddr *)&srv_addr, sizeof(srv_addr)) <0 )
    {
        printf("Error: bind(%d) failed[%d]\n", sockid, errno);
        exit(1);
    }
    if(listen(sockid,5) < 0)
    {
        printf("Error: listen(%d) failed[%d]\n", sockid, errno);
        exit(1);
    }
	count=10000;
    while(1)
    {	
        clilen = sizeof(cli_addr);
        printf("clilen=[%d],sockid=[%d]\n",clilen,sockid);
        memset(&cli_addr, 0x0, sizeof(cli_addr));
        subsockid = accept(sockid, (struct sockaddr *)&cli_addr, &clilen);
        if(subsockid < 0)
        {       	
            printf("Warning: accept(%d) faile[%d]\n", sockid, errno);
            if(count--)
                continue;
            else
                break;
        }
        pid = fork();
        if(pid == 0)
        {	
            close(sockid);
            while(1)
            {
                /* ��ȡ����ͷ��Ϣ */
                memset(vMsgHead, 0x0, sizeof(vMsgHead));
                if(read(subsockid,vMsgHead,MSGHEAD_LEN) != MSGHEAD_LEN)
                {
                    printf("Error: read Head(%d) failed[%d]\n", subsockid, errno);
                    sleep(1);
                    close(subsockid);
                    exit(1);
                }
                /*��ʼȡ����ͷ������Ϣ*/
                memset(&vTransMsg,0x0,sizeof(vTransMsg));
                SinitMsgHead(vMsgHead, &vTransMsg);
                printf("����ı���ͷ��Ϣ���£�[%s][%s][%s][%s][%s][%s][%s][%s][%s]\n",vTransMsg.vMsgHead.msgflag,vTransMsg.vMsgHead.msgtype,vTransMsg.vMsgHead.servtype,vTransMsg.vMsgHead.username,vTransMsg.vMsgHead.userpswd,vTransMsg.vMsgHead.msgno,vTransMsg.vMsgHead.reserved,vTransMsg.vMsgHead.mobile,vTransMsg.vMsgHead.begintime);

                /*����������Ϣ*/
                iRecvMsgLen=105;
                printf("��������ݳ���=[%d],����ͷ����=[%d]\n",iRecvMsgLen,MSGHEAD_LEN);

				/*��֯������*/
				strcpy(vmsgtype,vTransMsg.vMsgHead.servtype);
				printf("vmsgtype=[%s]\n",vmsgtype);
				/*ҵ��ͨ*/
				if(strncmp(vmsgtype,"KT:DXHZ",7)==0)
					{	
						printf("��ʼ��֯���ͱ���\n");
						/*
						strcpy(pTmpFile,"svrName=BossDemo&%24xmldata=");
						
						sprintf(vMsgBuff,"<?xml version=\"1.0\" encoding=\"GBK\"?><operation_in><service_name>mb_biz_proc</service_name><verify_code>200506021527497373284</verify_code><request_type>1002</request_type><sysfunc_id>93001003</sysfunc_id><request_time>%s</request_time><request_seq>100393231472</request_seq><request_source>101101</request_source><request_target>102009</request_target><msg_version>0100</msg_version><cont_version>0100</cont_version><content><BizProcReq><ObjectType>01</ObjectType><ObjectID>%s</ObjectID><HomeCity>431</HomeCity><OprCode>%s</OprCode><BizType>13</BizType><Passwd>%s</Passwd><NewPasswd>%s</NewPasswd><BrandID>2</BrandID><OprTime>%s</OprTime><UserStatus>%s</UserStatus><StatusChgTime>%s</StatusChgTime></BizProcReq></content></operation_in>",vTransMsg.vMsgHead.begintime,vTransMsg.vMsgHead.mobile,"01","","",vTransMsg.vMsgHead.begintime,"00",vTransMsg.vMsgHead.begintime);
						*/
						
						strcpy(pTmpFile,"");
						
						strcpy(vMsgBuff,"<?xml version=\"1.0\" encoding=\"GBK\"?><operation_in><service_name>mb_biz_proc</service_name><verify_code>200506021527497373284</verify_code><request_type>1002</request_type><sysfunc_id>93001003</sysfunc_id><request_time>20050602145820</request_time><request_seq>100393231472</request_seq><request_source>101101</request_source><request_target>102009</request_target><msg_version>0100</msg_version><cont_version>0100</cont_version><content><BizProcReq><ObjectType>01</ObjectType><ObjectID>13504702424</ObjectID><HomeCity>431</HomeCity><OprCode>01</OprCode><BizType>13</BizType><Passwd/><NewPasswd/><BrandID>2</BrandID><OprTime>20050602145820</OprTime><UserStatus/><StatusChgTime/></BizProcReq></content></operation_in>");
						
						strcat(pTmpFile,vMsgBuff);
						
						printf("�����͵ı���=[%s]\n",pTmpFile);
					}
					/*ҵ��ȡ��*/
				if(strncmp(vTransMsg.vMsgHead.msgtype,"QX:DXHZ",7)==0)
					{
						sprintf(pTmpFile,"svrName=BossDemo&%24xmldata=<?xml version=\"1.0\" encoding=\"GBK\"?><operation_in><service_name>mb_biz_proc</service_name><verify_code>200506021527497373284</verify_code><request_type>1002</request_type><sysfunc_id>93001003</sysfunc_id><request_time>%s</request_time><request_seq>100393231472</request_seq><request_source>101101</request_source><request_target>102009</request_target><msg_version>0100</msg_version><cont_version>0100</cont_version><content><BizProcReq><ObjectType>01</ObjectType><ObjectID>%s</ObjectID><HomeCity>431</HomeCity><OprCode>%s</OprCode><BizType>13</BizType><BrandID>2</BrandID><OprTime>%s</OprTime></BizProcReq></content></operation_in>",vTransMsg.vMsgHead.begintime,vTransMsg.vMsgHead.mobile,"02",vTransMsg.vMsgHead.begintime);
					}				
                /*����������Ϣ*/
			if(signal(SIGALRM,sigProcess) == SIG_ERR)
				{
					return(1000);
				}
				/*��ʼ���÷���*/
				
				
				connFlag = doPost(pTmpFile);
				switch(connFlag)
				{
                	case  -1:
                                printf("Create Net Link ERROR!");
                        retCode=1003;
                	case  -2:
                                printf("Cannot Connect WebServer!");
                        retCode=1004;
        			default:
						retCode=0000;
    			}
    			
    			printf("4444444444444444444444444444444\n");
    			/*����Ӧ����Ϣ sockFD*/
    			sockFD=connFlag;
    			/*
    			fclose(pTmpFile);
    			*/
				printf("ʡBOSS������ı���dopost�����Ż�ִƽ̨�ɹ�\n");
				sleep(1);
                
				sigFlag=0;
				printf("��������ǰsockFD=[%ld]\n",sockFD);
				
				httpCode = recvHttpHead(sockFD, &vRspMsg);
				
				/*��鷵�������Ƿ�Ϊ��*/
			
				if((sigFlag == 1) || (strlen(vRspMsg) <= 0))
				{
						alarm(0);
                		close(sockFD);
				}
				
				if(strlen(vRspMsg) == 0)
				{
					printf("δ���յ�Ӧ������!");
                	close(sockFD);
                	return (2000);
				}
				
				alarm(2);
				printf("[%s][%d] recvLength = [%d][%ld][%s]\n",__FILE__,__LINE__,rcvLength,sigFlag,vRspMsg);
				/*��ʼ��ȡ����MAX_LENGTH*/
				/*
			memset(msgBuffer,0x0,sizeof(msgBuffer));				
			do
			{
				
				n = readFromWebServer(sockFD,recvline,rcvLength);
				if(n < 0){
        			printf("Receive Data From Web ERROR!\n");
        			retCode=1007;
        			
        		}
				else if(n > 0)
				{
					strcat(msgBuffer,(char *)recvline);
					rcvLength = rcvLength - n;
				}
			if(rcvLength <= 0)break;
			} while( n > 0);
			*/
			/*��ȡӦ�����*/
			
			strcpy(vFindStr,"<resp_code>");
			q=findstr(vRspMsg,vFindStr,&return_code);
			
			printf("��ʼӦ��ָ����ϢretCode=[%s][%s]\n",retCode,return_code);
			/*����Ӧ����Ϣ*/
			memset(vMsgBuff,'\0',sizeof(vMsgBuff));
			if(atoi(return_code) == 0)
                { 
					sprintf(vMsgBuff,"%s%s%-15s%-10s%-10s%sRETN=00%s%189s","`BD`","1","KT:DXHZ","jifee","jifee","                                ","0000","");
                }
                else
                {
					sprintf(vMsgBuff,"%s%s%-15s%-10s%-10s%sRETN=00%s%189s","`BD`","1","KT:DXHZ","jifee","jifee","                                ","0002","");
                }
#ifdef _DEBUG_
                printf("retCode:[%d] vMsgBuff:[%s]\n",retCode,vMsgBuff);
#endif               
				iSendLength=272; 
                if(write(subsockid, vMsgBuff, iSendLength)!= iSendLength)
                {
                    printf("Error: write(%d) failed[%d]\n", subsockid, errno);
                    sleep(1);
                    close(subsockid);
                    exit(1);
                }

            }
        }
        
        close(subsockid);
    }    
 
}



void error_handler()
{
	s_debug("====EXEC SQL ERROR BEGIN\n");
	s_debug("====sqlca.sqlcode=[%d],sqlca.sqlerrm.sqlerrmc=[%s]\n",\
              sqlca.sqlcode,sqlca.sqlerrm.sqlerrmc);
	s_debug("====EXEC SQL ERROR END\n");
}

void warning_handler()
{
	s_debug("----EXEC SQL WARNING BEGIN\n");
	s_debug("----sqlca.sqlcode=[%d],sqlca.sqlerrm.sqlerrmc=[%s]\n",\
              sqlca.sqlcode,sqlca.sqlerrm.sqlerrmc);
        s_debug("----EXEC SQL WARNING END\n");
}


void
IgnoreAllSignal()
{
struct sigaction act;

	act.sa_handler = SIG_IGN;
	sigemptyset(&act.sa_mask);
	act.sa_flags=0;
	sigaction(SIGHUP,&act,NULL);
	sigaction(SIGCHLD,&act,NULL); 
	sigaction(SIGQUIT,&act,NULL);
	
	return ;
}

void LogOut(int sig)
{
	s_debug("process is killed\n");
	exit(1);
}

/*----------------------------------------------*/
/* read from WebServer by bytes                 */
/*----------------------------------------------*/

int readFromWebServer(fd,vptr,maxlen)
int  fd;
char * vptr;
int maxlen;
{
        int n,k=0;
        int rc;
        char * ptr;
        char c;

        ptr = (char *)vptr;
        for(n=1;n<maxlen;n++)
        {
                if((rc = read(fd,&c,1)) == 1)
                {
                        *ptr++ = c;
                        printf("k=[%d][%d]\n",k,n);
                        if(k>650)
                        {
                                *ptr = '\0';
                                return n;
                        }
                        k++;
                }
                else if(rc == 0)
                {
                        if(n == 1) return 0;
                        else
                        {
                                *ptr = '\0';
								return n;
                        }
                }
                else
                        return -1;
        }
        *ptr = '\0';
        return n;
}
SinitMsgHead(char *MsgHead, TransMsg *vTransMsg)
{		
	char msgflag[4+1];
	char msgtype[1+1];
	char servtype[15+1];
	char username[10+1];
    char userpswd[10+1];
    char msgno[16+1];
    char reserved[16+1];
    char mobile[20+1];
    char begintime[14+1];
    memset(msgflag,'\0',sizeof(msgflag));
    memset(msgtype,'\0',sizeof(msgtype));
    memset(servtype,'\0',sizeof(servtype));
    memset(username,'\0',sizeof(username));
    memset(userpswd,'\0',sizeof(userpswd));
    memset(msgno,'\0',sizeof(msgno));
    memset(reserved,'\0',sizeof(reserved));
    memset(mobile,'\0',sizeof(mobile));
    memset(begintime,'\0',sizeof(begintime));
    	  
    strncpy(msgflag, MsgHead,4);
    strncpy(msgtype, MsgHead+4,1);
    strncpy(servtype, MsgHead+5,15);
    strncpy(username, MsgHead+20,10);
	strncpy(userpswd, MsgHead+30,10);
    strncpy(msgno, MsgHead+40,16);
    strncpy(reserved, MsgHead+56,16);
    strncpy(mobile,MsgHead+72,20);
    strncpy(begintime,MsgHead+92,14);
    
	strcpy(vTransMsg->vMsgHead.msgflag,msgflag);
    strcpy(vTransMsg->vMsgHead.msgtype,msgtype);
    strcpy(vTransMsg->vMsgHead.servtype,servtype);
    strcpy(vTransMsg->vMsgHead.username,username);
	strcpy(vTransMsg->vMsgHead.userpswd,userpswd);
    strcpy(vTransMsg->vMsgHead.msgno,msgno);
    strcpy(vTransMsg->vMsgHead.reserved,reserved);
	strcpy(vTransMsg->vMsgHead.mobile,mobile);
    strcpy(vTransMsg->vMsgHead.begintime,begintime);
    printf("vTransMsg->vMsgHead.msgflag=[%s]\n",vTransMsg->vMsgHead.msgflag);
    printf("vTransMsg->vMsgHead.msgtype=[%s]\n",vTransMsg->vMsgHead.msgtype);
    printf("vTransMsg->vMsgHead.servtype=[%s]\n",vTransMsg->vMsgHead.servtype);
    printf("vTransMsg->vMsgHead.username=[%s]\n",vTransMsg->vMsgHead.username);
    printf("vTransMsg->vMsgHead.userpswd=[%s]\n",vTransMsg->vMsgHead.userpswd);
    printf("vTransMsg->vMsgHead.msgno=[%s]\n",vTransMsg->vMsgHead.msgno);
    printf("vTransMsg->vMsgHead.reserved=[%s]\n",vTransMsg->vMsgHead.reserved);
	printf("vTransMsg->vMsgHead.mobile=[%s]\n",vTransMsg->vMsgHead.mobile);
    printf("vTransMsg->vMsgHead.begintime=[%s]\n",vTransMsg->vMsgHead.begintime);

}
/*------------------------------------------*/
/*-- get Http message code and message len--*/
/*------------------------------------------*/
 
int recvHttpHead(int sockFD, char *RspMsg)
{
	int  n=0,i,j;
	char recvLine[MAX_LENGTH];
	char httpCode[4];
	char cLength[20];

	memset(cLength,'\0',sizeof(cLength));
	memset(recvLine, '\0',sizeof(recvLine));
	memset(httpCode, '\0',sizeof(httpCode));
	printf("��ʼ��ȡ��������\n");
	for(i=0 ; i<1;i++)
	{
		printf("i=[%d]\n",i);
		if((n = readFromWebServer(sockFD,recvLine,MAX_LENGTH)) <= 0)
		{
			printf("readFromWebServer��ȡ����ʧ��n=[%d]!\n",n);
			printf("���ص�����ΪrecvLine=[%s]\n",recvLine);
			return -1;
		}
		else
		{
			printf("#### recvHttpHead line [%s]\n",recvLine);
			if(memcmp(recvLine,"HTTP",4) == 0)
			{
				strncpy(httpCode,recvLine+9,3);
			}
			if(memcmp(recvLine,"size:",5) == 0)
			{
				strcpy(cLength,recvLine+6);
				j = strlen(cLength);
				while((j > 0) && ((cLength[j-1] < '0') || (cLength[j-1] > '9')))
				{
					j--;
					cLength[j] = '\0';
				}
			}
			if(strcmp(recvLine,"\r\n") == 0) break;
		}
		
		printf("���ص��û���Ϣ11111111111recvLine=[%s]\n",recvLine);
		
		
	}

	printf("####httpCode = [%s]\n",httpCode);
	printf("####httpCode = [%s]\n",httpCode);
	printf("#### int httpCode = [%d]\n",atoi(httpCode));
	printf("#### int httpCode = [%d]\n",atoi(httpCode));
	printf("#### recvLength = [%s]\n",cLength);
	printf("#### recvLength = [%s]\n",cLength);
	strcpy(RspMsg,recvLine);
	printf("���ص�����Ϊ=[%s]\n",RspMsg);
	return (atoi(httpCode));
}
int doPost(FILE *pTmpFile)
{
    struct sockaddr_in serv_addr;
    struct hostent* hostptr;
	struct  stat     fileStat;
	FILE    *fp;
	int    iFileNo;
	int    postLength=0,sockFD,count;
	char   *name;
	char    tmp[LINE+1];
	char   tmpLine[128];
	char   sendLine[512+1];
	char   httpHead[1024];
	char   httpContent[1024*10];
	char   file_name[120+1];
	int    testlen=0;

	char this_db[30];	
	char this_srv[30];	
	int postport;
	char postip[30];
	
	
	/*-----------------------------------*/
	/* Prepare to connect to WebServer  */
	/*-----------------------------------*/
	/*�������ļ�����ȡIP��ַ port�˿ں�*/
	printf("��ʼ��ȡpost�����ļ�\n");
	snprintf(file_name, sizeof(file_name), "%s%s%s%s", getenv("WORKDIR"), CFGDIR, SPRI, DXHZCFG);
	if (file_name == NULL) {
		printf("get pathname err!\n");
		return(-1);
		}
		printf("file_name=[%s]\n",file_name);
	if ((fp = fopen(file_name,"r")) == NULL) {
		printf("open file err!\n");
		return(-1);
        }
		while(fgets(tmp, LINE, fp) != NULL)  {
			if (tmp[0] != COMMENT)
			{
				printf("��ʼ��ȡ������Ϣ\n");
				sscanf(tmp,"%s%s",dxhzcfg[0].ipaddr,dxhzcfg[0].portno);
				printf("��ȡ���û���IP��ַ�Ͷ˿ں�Ϊ[%s][%s][%s]\n",dxhzcfg[0].ipaddr,dxhzcfg[0].portno,tmp);
        	}
        }
        fclose(fp);
        
	memset(postip, 0x0, sizeof(postip));
	postport = atoi(dxhzcfg[0].portno);
	strcpy(this_srv,dxhzcfg[0].ipaddr);
	
	strcpy(postip,this_srv);	

    printf("POSTIP=%s,POSTPORT=%d\n",postip,postport);

    if((sockFD = socket(PF_INET,SOCK_STREAM,0)) < 0){
        printf("Can't Open stream socket");
        return(-1);
    }
	printf("��socket�˿����sockFD=[%d]\n",sockFD);
    bzero((char*)&serv_addr,sizeof(serv_addr));
    serv_addr.sin_family = AF_INET;
/*
��SERVER_NAME�滻Ϊ10.161.1.118
*/
    hostptr = gethostbyname(postip);

    if(hostptr == 0){
        return(-1);
    }
    name = inet_ntoa(*(struct in_addr*)*hostptr->h_addr_list);
    serv_addr.sin_addr.s_addr = inet_addr(name);

    serv_addr.sin_port = htons(postport);

    if(connect(sockFD,(struct sockaddr*)&serv_addr,sizeof(serv_addr))<0)
    {
        printf("Cant't conect to server");
        return(-1);
    }

    printf("++ Conect to server SUCESS !!! ++\n");

	/* Begin to Send Message to WebServer */
	/*-----------------------------------*/
	/* Orgernize http Header */
	/*-----------------------------------*/
    printf("++ 1 Conect to server SUCESS !!! ++\n");
    if(strlen(pTmpFile) == 0) printf("���ͱ���Ϊ�ա�\n");
	/*
	iFileNo = fileno(pTmpFile);
	fstat(fileno(pTmpFile), &fileStat);
	*/
	fstat(fileno(pTmpFile), &fileStat);
	
    printf("++ 2 Conect to server SUCESS !!! ++\n");
    printf("����=[%ld]\n",fileStat.st_size);
    memset(sendLine,'\0',sizeof(sendLine));
	sprintf(sendLine,"Content-Length: %ld\n\n",strlen(pTmpFile));
    printf("++ 3 Conect to server SUCESS !!! ++\n");
	printf("sendLine=[%s]\n",sendLine);
	memset(httpHead,'\0',sizeof(httpHead));
	strcat(httpHead,POSTURL);
	
	/*
	strcat(httpHead,"Connection: Keep-Alive\n");
	strcat(httpHead,"User-Agent: Mozilla/2.0\n");
	strcat(httpHead,"Accept: text/plain\n");
	strcat(httpHead,"Accept: text/html\n");
	strcat(httpHead,"Content-type: application/x-www-form-urlencoded\n");
	*/
/*	
	strcat(httpHead,"Content-Type: text/xml\n");
	strcat(httpHead,"Accept: text/xml\n");
	strcat(httpHead,"Connection: Keep-Alive\n");
	strcat(httpHead,"User-Agent: Mozilla/4.0 (compatible; MSIE 5.5; Windows NT 5.0)\n");
*/	

	strcat(httpHead,"Content-Type: text/xml");
	strcat(httpHead,"Accept: text/xml\n");
	strcat(httpHead,"Connection: Keep-Alive\n");
	strcat(httpHead,"User-Agent: Mozilla/4.0 (compatible; MSIE 5.5; Windows NT 5.0)\n");
	strcat(httpHead,"Host: 10.161.112.61:55555\n");

	strcat(httpHead,sendLine);
	strcat(httpHead,pTmpFile);
                     
    printf("++ 4 Conect to server SUCESS !!! ++\n");
                     
#ifdef _DEBUG_       
	printf("[%s]HTTPHEAD == [%s]++[%s]\n",__FILE__,httpHead,pTmpFile);
#endif               
	
	/*-----------------------------------*/
	/* Send httpHeader To WebServer */
	/*-----------------------------------*/
	postLength = strlen(httpHead);
	printf("���͵ĳ���=[%ld][%s]\n",postLength,httpHead);
    if(writenn(sockFD,httpHead,postLength) != postLength)
    {   
		printf("send httpHeader data unSucessfully !! \n");
        return(-2);
    }
	/*--------------------------------------------*/
	/* Send Message file(xml format) To WebServer */
	/*--------------------------------------------*/
	printf("Send httpHead end [%d]\n",sizeof(sendLine));
	
	rewind(pTmpFile);
	printf("2222222222222222222222222\n");
	/*
	while(fgets(sendLine,sizeof(sendLine),pTmpFile) != NULL)
	{
		printf("pTmpFil��Ϊ��\n");
		postLength = strlen(sendLine);
    	if(writenn(sockFD,sendLine,postLength) != postLength)
    	{   
			printf("send message header data unSucess!! \n");
       	 	return(-2);
    	}
	}
	*/
	printf("33333333333333333333333333\n");
	/*
	fclose(pTmpFile);
	*/
	printf("send Message Data file  Sucessfully End !! \n");
	printf("send Message Data file  Sucessfully End !! \n");

    return sockFD;

}
int writenn(fd,vptr,n)
int fd;
char* vptr;
unsigned n;
{
	int nleft;
	int nwritten;
	char * ptr;
	char * pSend;

	/*pSend = convert(vptr,"ISO-8859-1");*/
	ptr = (char *)vptr;
	nleft = n;
	while(nleft > 0)
	{	printf("��ʼд����\n");
		if((nwritten = write(fd,ptr,nleft)) <= 0)
			 return nwritten;
		nleft -= nwritten;
		ptr += nwritten;
	}
	return(n - nleft);
}
int findstr(char *p ,char *q ,char *Msg)
{
        int i ,j,jc,n;
        char tmpstr[1024*2+1];
        char findstr[10];
        char return_code[4+1];
        strcpy(findstr,q);
        for(i=0;i<strlen(p);i++)
        {
                printf("1111111111p=[%s]\n",&p[i]);
                strcpy(tmpstr,&p[i]);
                if(strncmp(tmpstr,findstr,11)==0)
                {
                		strcpy(tmpstr,&p[i+11]);
                		strncpy(return_code,tmpstr,4);
                		strcpy(Msg,return_code);
                        printf("�����ַ����ɹ�=[%d][%s]\n",i,Msg);
                        return i;
                }

        }
        return -1;

}