
#define SQLCODE sqlca.sqlcode
/*
SQLCA sqlca;
*/
#define SQL_OK 0
#define NO_MORE_ROWS 1403
#define SQLROWS sqlca.sqlerrd[2]

#define ERREXIT -1
#define STDEXIT 0

#define CODESIZ		6
#define ORDERSIZ	9

extern int  Dblogin();
extern int  Dbclose();
extern void error_handler();
extern void warning_handler();
