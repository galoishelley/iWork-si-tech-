#ifndef __ONOFF_H
#define __ONOFF_H

#include <stdio.h>
#include <fcntl.h>
#include <signal.h>
#include <errno.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <sys/times.h>
#include <sys/types.h>
#include <unistd.h>
#include <sys/stat.h>
#include <sys/socket.h>
#include <sys/time.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <sys/sem.h>
#include <sys/wait.h>
#include <sys/errno.h>
#include <netinet/in.h>
#include <netdb.h>
#include <stdarg.h>
#include <errno.h>
#include <syslog.h>
/* for sco5.0.5 */
#include <arpa/inet.h>
#include <setjmp.h>
#include <termio.h>

#define NO_DEBUG
#define MSCDEBUG

#define OK		0
#define NO_MORE_ROWS	1403

#define LEN		sizeof(struct para)
#define MSGKEY	5610 
#define MSGKEY1	5611
#define MSGKEY2	5612
#define MSGKEY3	5613
#define MSGKEY4	5614
#define MSGKEY5	5615
#define MSGKEY6	5616

#define MSGBASEKEY	5600


#define GSNDMSGTYPE	1
#define GRCVMSGTYPE	2
#define GSMUSER		"/cfg/gsmuser.cfg"
#define GSMUSER1	"/cfg/gsmuser1.cfg"
#define GSMCMDFORM	"/cfg/gcmdform.cfg"
#define LOGDIRECTORY	"/log/"
#define DFFILE		"/log/dfimsi"
#define MSGKEYDIR 	"/cfg/msgkeydir"
#define MSGKEYDIR1 	"/cfg/msgkeydir1"
#define QUERY		"/cfg/query.cfg"
#define MSGSIZE 	128
#define STRINGLEN	2048 /* circle link table length */

#define GSNDTYPE	2
#define GRCVTYPE	1

#define 	PERMS 		0660

#define         SNOFILE         1024

#define SERVICE    "/cfg/gservice.cfg"
#define SERVICE1   "/cfg/gservice1.cfg"
#define SERVERHOST "/cfg/gsvrhost.cfg"
#define SYBLOGIN   "/cfg/gdblogin.cfg"

typedef struct para 
{
	char ChVal;
	struct para *next;
}PARA;

typedef struct msgbuf1
{
	int  mtype;
	char mtext[MSGSIZE];
}MSGBUF;

typedef struct cmd
{
	int	flag;
	int	freetimes;
	char	command_id[20];
	char	hlr_code[4];
	char	id_no[20];
	char	belong_code[8];
	char	command_order[4];
	char	phone_no[16];
	char	sm_code[4];
	char	login_no[8];
	char	total_date[8];
	char	login_accept[4];
	char	op_code[4];
	char	org_code[12];
	char	command_code[4];
	char	imsi_no[20];
	char	other_char[140];
	char	new_phone[16];
	char	new_imsi[20];
	char	business_status[4];
	char	request_time[24];
	char	send_status[4];
	char	send_time[24];
} CMD_SEND;

typedef struct cmdback
{
	char    phone_no[16];
	char    command_code[4];
	char    ret_code[8];
	char    ret_all[64];
} CMD_BACK;

typedef struct sndcmd
{
	char	statcode[6];
	char	sndmsgkey[6];
	char	rcvmsgkey[6];
	char	NetBuf[128];
}NETCMD;

#define TCPBUFLEN	sizeof(CMDTCP)

#endif  /* __ONOFF_H */
