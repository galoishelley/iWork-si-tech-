#include <time.h> 
#include <stdio.h>
#include <varargs.h>
#include <strings.h>
#include <sys/time.h>
#include <sys/times.h>

#define         TRUE     1
#define         FALSE    0

void
s_debug(va_alist)
va_dcl
{
	va_list args;
	char 	*fmt;
	FILE	*fp;
	char filename[128],*ttyname(),*tname;
	char tmpstr[256];
	struct tm tv;
	long t;

	time(&t);
        tv=*localtime(&t);
	tname=ttyname(TRUE);
	sprintf(filename,"%s/log/%04d%02d%02d",getenv("WORKDIR"),\
		tv.tm_year+1900,tv.tm_mon+1,tv.tm_mday);
	fp=fopen(filename,"a");
	va_start(args);
	fmt=va_arg(args,char *);
	vfprintf(fp,fmt,args);
	vfprintf(stdout,fmt,args);
	va_end(args);

        fprintf(fp,"TIME:%04d/%02d/%02d %02d:%02d:%02d\n\n",\
		tv.tm_year+1900,tv.tm_mon+1,tv.tm_mday,\
                tv.tm_hour,tv.tm_min,tv.tm_sec);

	fclose(fp);
}


